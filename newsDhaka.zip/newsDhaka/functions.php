<?php 
/**
 * News Theme functions and definitions
 *
 * Sets up the theme and provides some helper functions. 
 *
 * @package WordPress
 * @subpackage selim_Reza
 */
 
/* Adding Latest jQuery from Wordpress */
/**
 * Required: set 'ot_theme_mode' filter to true.
 */
/* Required: include OptionTree. */

 include_once('inc/breadcumbs.php'); 
 
add_filter( 'ot_theme_mode', '__return_true' );

/**
 * Required: include OptionTree.
 */
require( trailingslashit( get_template_directory() ) . 'option-tree/ot-loader.php' );
/**
 * Theme Options
 */
require( trailingslashit( get_template_directory() ) . 'inc/theme-options.php' );

function news_latest_jquery() {
	wp_enqueue_script('jquery');
}
add_action('init', 'news_latest_jquery');

/* adding theme supports */

add_theme_support( 'post-thumbnails', array( 'post', 'galary', 'slider' ) );

/* Post Thumbnail size */

set_post_thumbnail_size( 800, 451, true );
add_image_size( 'top-image', 150, 150, true );
add_image_size( 'slider-image', 448, 330, true );
add_image_size( 'recent-image', 150, 110, true );
add_image_size( 'mega-image', 470, 445, true );
add_image_size( 'carousel-image', 235, 150, true );

/* Register Main Menus */

function register_menus() {
  register_nav_menus(
    array(
      'main-menu' => __( 'Main Menu' ),
      'footer-menu' => __( 'Footer Menu' ),
	  'mobile-menu' => __( 'Mobile Menu' )
    )
  );
}
add_action( 'init', 'register_menus' );

/* custom Posts */

	add_action( 'init', 'create_post_type' );
	function create_post_type() {
	
	
		register_post_type( 'galary',
			array(
				'labels' => array(
						'name' => __( 'Galary Slide' ),
						'singular_name' => __( 'Galary Slide' ),
						'add_new' => __( 'Add New' ),
						'add_new_item' => __( 'Add New Slide' ),
						'edit_item' => __( 'Edit Galary Slide' ),
						'new_item' => __( 'New Galary Slide' ),
						'view_item' => __( 'View Galary Slide' ),
						'not_found' => __( 'Sorry, we couldn\'t find the Galary Slide Images you are looking for.' )
				),
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => true,
			'menu_position' => 14,
			'has_archive' => true,
			'hierarchical' => true,
			'capability_type' => 'post',
			'rewrite' => array( 'slug' => 'galary' ),
			'supports' => array( 'title', 'custom-fields', 'thumbnail' )
			)
		);
		
		register_post_type( 'slider',
			array(
				'labels' => array(
						'name' => __( 'Slider' ),
						'singular_name' => __( 'slider' ),
						'add_new' => __( 'Add New' ),
						'add_new_item' => __( 'Add New slid' ),
						'edit_item' => __( 'Edit slid' ),
						'new_item' => __( 'New slid' ),
						'view_item' => __( 'View slider' ),
						'not_found' => __( 'Sorry, we couldn\'t find the Slide you are looking for.' )
				),
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => true,
			'menu_position' => 14,
			'has_archive' => true,
			'hierarchical' => true,
			'capability_type' => 'post',
			'rewrite' => array( 'slug' => 'slider' ),
			'supports' => array( 'title','custom-fields', 'thumbnail' )
			)
		);
			
	}
/* widget register */

function news_gidget_aria(){
	/* Sidebar One SpotLight */
	register_sidebar(array(
	'name' => __('Sidebar SpotLight'),
	'id' => 'sidebar_one',
	'before_widget' => '<div class="soptlight">',
	'after_widget' => '</div>',
	'before_title' => '<h2>',
	'after_title' => '</h2>'
	));
	/* Sidebar Two Muktomot */
	
	register_sidebar(array(
	'name' => __('Sidebar Two Muktomot'),
	'id' => 'sidebar_two',
	'before_widget' => '<div class="recent-right">',
	'after_widget' => '</div>',
	'before_title' => '<div class="title"><h2>',
	'after_title' => '</h2></div>'
	));
	/* footer Top */
	register_sidebar(array(
	'name' => __('Footer Widget Top'),
	'id' => 'footer_top',
	'before_widget' => '<div class="widget_top">',
	'after_widget' => '</div>',
	'before_title' => '<h2 style="display:none">',
	'after_title' => '</h2>'
	));
	/* footer one*/
	register_sidebar(array(
	'name' => __('Footer Widget One'),
	'id' => 'footer_aria_one',
	'before_widget' => '<div class="footer-widget1">',
	'after_widget' => '</div>',
	'before_title' => '<h4 class="dis-none">',
	'after_title' => '</h4>'
	));
	/* footer two*/
	register_sidebar(array(
	'name' => __('Footer Widget Two'),
	'id' => 'footer_aria_two',
	'before_widget' => '<div class="footer-widget2">',
	'after_widget' => '</div>',
	'before_title' => '<h2 style="display:none">',
	'after_title' => '</h2>'
	));
        /* footer three*/
	register_sidebar(array(
	'name' => __('Footer Widget Three'),
	'id' => 'footer_aria_three',
	'before_widget' => '<div class="footer-widget3">',
	'after_widget' => '</div>',
	'before_title' => '<h2 style="display:none">',
	'after_title' => '</h2>'
	));
	  /* footer Four */
	register_sidebar(array(
	'name' => __('Footer Widget Four'),
	'id' => 'footer_aria_four',
	'before_widget' => '<div class="footer-widget4">',
	'after_widget' => '</div>',
	'before_title' => '<h2 style="display:none">',
	'after_title' => '</h2>'
	));
	
}
add_action('widgets_init' , 'news_gidget_aria');

/* custom taxonomy */

	/* Sylhet */
	function sylhet_taxonomy() {
		register_taxonomy(
			'sylhet',  
			'post',                  //post type name
			array(
				'hierarchical'          => true,
				'label'                 => 'sylhet',  //Display name
				'query_var'             => true,
				'show_admin_column' => true,
				'rewrite'               => array(
					'slug'              => 'sylhet', 
					'with_front'    	=> false 
					)
				)
		);
		register_taxonomy(
			'dhaka',  
			'post',                  //post type name
			array(
				'hierarchical'          => true,
				'label'                 => 'dhaka',  //Display name
				'query_var'             => true,
				'show_admin_column' => true,
				'rewrite'               => array(
					'slug'              => 'dhaka', 
					'with_front'    	=> false 
					)
				)
		);
		register_taxonomy(
			'khulna',  
			'post',                  //post type name
			array(
				'hierarchical'          => true,
				'label'                 => 'khulna',  //Display name
				'query_var'             => true,
				'show_admin_column' => true,
				'rewrite'               => array(
					'slug'              => 'khulna', 
					'with_front'    	=> false 
					)
				)
		);
		register_taxonomy(
			'barishal',  
			'post',                  //post type name
			array(
				'hierarchical'          => true,
				'label'                 => 'barishal',  //Display name
				'query_var'             => true,
				'show_admin_column' => true,
				'rewrite'               => array(
					'slug'              => 'barishal', 
					'with_front'    	=> false 
					)
				)
		);
		register_taxonomy(
			'rajshahi',  
			'post',                  //post type name
			array(
				'hierarchical'          => true,
				'label'                 => 'rajshahi',  //Display name
				'query_var'             => true,
				'show_admin_column' => true,
				'rewrite'               => array(
					'slug'              => 'rajshahi', 
					'with_front'    	=> false 
					)
				)
		);
		register_taxonomy(
			'chittagong',  
			'post',                  //post type name
			array(
				'hierarchical'          => true,
				'label'                 => 'chittagong',  //Display name
				'query_var'             => true,
				'show_admin_column' => true,
				'rewrite'               => array(
					'slug'              => 'chittagong', 
					'with_front'    	=> false 
					)
				)
		);
		register_taxonomy(
			'mahmangshing',  
			'post',                  //post type name
			array(
				'hierarchical'          => true,
				'label'                 => 'mahmangshing',  //Display name
				'query_var'             => true,
				'show_admin_column' => true,
				'rewrite'               => array(
					'slug'              => 'mahmangshing', 
					'with_front'    	=> false 
					)
				)
		);
		register_taxonomy(
			'rangpur',  
			'post',                  //post type name
			array(
				'hierarchical'          => true,
				'label'                 => 'rangpur',  //Display name
				'query_var'             => true,
				'show_admin_column' => true,
				'rewrite'               => array(
					'slug'              => 'rangpur',
					'with_front'    	=> false 
					)
				)
		);
	}
	add_action( 'init', 'sylhet_taxonomy');


	/* readmore functions  */

function excerpt($num, $read) {

$limit = $num+1;

$excerpt = explode(' ', get_the_excerpt(), $limit);

array_pop($excerpt);

$excerpt = implode(" ",$excerpt)." <a href='" .get_permalink($post->ID) ." ' class='".readmore."'>".$read."</a>";

echo $excerpt;

	}	
	
?>