<?php get_header(); ?>
		<!-- header -->
		<?php get_template_part('top-news'); ?>
		<!-- TOP NEWS -->
		<section class="ads">
			<div class="container">
				<div class="row">
					<div class="col-md-6"> 
						<?php
							$ads1 = ot_get_option('slider_top_one');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
					<div class="col-md-6">
						<?php
							$ads2 = ot_get_option('slider_top_two');
						?>
						<?php if($ads2 != "" ){ ?>
							<img src="<?php echo $ads2; ?>" alt="" />
						<?php } ?>
					</div>
				</div>
			</div>
		</section>
		<!-- ADS -->
		<section class="slider-content">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<div class="slider">
							<div class="main-flexslider">
							  <ul class="slides">
							 <?php $recent = ot_get_option('slider'); ?>
							<?php if( $recent != "" ){ 
									$recent = get_the_category_by_ID($recent); ?>
									<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$recent.'',
											'posts_per_page' => 5
										);
									$query = new WP_Query( $args );
													
									?>
									<?php while ( $query->have_posts() ) {
									$query->the_post();
									?>
										<li>
											<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
											<figcaption class="slider-cap">
											<a href="<?php the_permalink(); ?>"><?php the_title();?> </a>
											</figcaption>
										</li>
									<?php }
									wp_reset_postdata();
								?>
								<?php }else{

									global $post;
									$args = array( 'posts_per_page' => 6, 'post_type'=>'slider' );			
													
									$myposts = get_posts( $args );
									foreach( $myposts as $post ) : setup_postdata($post); 	
									
									?>			
										<li>
											<a href="<?php the_permalink(); ?>"><img src="<?php $slide_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'slider-image' ); echo $slide_image[0]; ?>" alt="Galary Images"/></a>
											<figcaption class="slider-cap">
											<a href="<?php the_permalink(); ?>"><?php the_title();?> </a>
											</figcaption>
										</li>
									<?php endforeach; 
								
								} ?>
							  </ul>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="slid-tab">

						  <!-- Nav tabs -->
						  <div class="tab-parent">
							<ul class="nav nav-tabs" role="tablist">
							
							<?php $single1 = ot_get_option('news_tab_one');
							$cat_name = "";
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
							<li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab"><?php echo $cat_name; ?></a></li>
							<?php $single1 = ot_get_option('news_tab_two');
							$cat_name = "";
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
							<li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab"> <?php echo $cat_name; ?> </a></li>
							<?php $single1 = ot_get_option('news_tab_three');
							$cat_name = "";
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							} ?>
							<li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab"> <?php echo $cat_name; ?> </a></li>
						  </ul>
						  </div>

						  <!-- Tab panes -->
						  <div class="tab-content">
							<div role="tabpanel" class="tab-pane active" id="home">
								<ul>
								<?php $recent = ot_get_option('news_tab_one');?>
							<?php if( $recent != "" ){ ?>
							<?php $recent=get_the_category_by_ID($recent); ?>
									<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$recent.'',
											'posts_per_page' => 5
										);
									$query = new WP_Query( $args );
													
									?>
									<?php while ( $query->have_posts() ) {
									$query->the_post();
									?>
									
											<li>
											<a href="<?php the_permalink(); ?>"> <?php the_title(); ?></a>
											</li>
											

									<?php }
									wp_reset_postdata();
								?>
								<?php } ?>
								</ul>
							</div>
							<div role="tabpanel" class="tab-pane" id="profile">
								<ul>
								<?php $recent = ot_get_option('news_tab_two');?>
							<?php if( $recent != "" ){ ?>
							<?php $recent=get_the_category_by_ID($recent); ?>
									<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$recent.'',
											'posts_per_page' => 5
										);
									$query2 = new WP_Query( $args );
													
									?>
									<?php while ( $query2->have_posts() ) {
										$query2->the_post();
									?>
											<li>
											<a href="<?php the_permalink(); ?>"> <?php the_title(); ?></a>
											</li>
									<?php }
									wp_reset_postdata();
								?>
								<?php } ?>
								</ul>
							</div>
							<div role="tabpanel" class="tab-pane" id="messages">
								<ul>
								<?php $recent = ot_get_option('news_tab_three');?>
							<?php if( $recent != "" ){ ?>
							<?php $recent=get_the_category_by_ID($recent); ?>
									<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$recent.'',
											'posts_per_page' => 5
										);
									$query = new WP_Query( $args );
													
									?>
									<?php while ( $query->have_posts() ) {
									$query->the_post();
									?>

											<li>
											<a href="<?php the_permalink(); ?>"> <?php the_title(); ?></a>
											</li>
									<?php }
									wp_reset_postdata();
								?>
								<?php } ?>
								</ul>
							</div>
						  </div>

						</div>
					</div>
					<div class="col-md-3 fix-padding">
						<?php dynamic_sidebar('sidebar_one'); ?>
					</div>
				</div>
			</div>
			
		</section>
		<!-- slider section -->
		<section class="recent-news">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="recent-content">
							
							<ul>
							<?php $recent = ot_get_option('recent_news');?>
							<?php if( $recent != "" ){ ?>
							<?php $recent=get_the_category_by_ID($recent); ?>
							<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$recent.'',
											'posts_per_page' => 4
										);
									$query3 = new WP_Query( $args );		
							?>
							<?php while ( $query3->have_posts() ) {
									$query3->the_post();
									?>
									<li title="<?php the_title(); ?>">
										<h2> <a href="<?php the_permalink(); ?>" > <?php the_title(); ?> </a> </h2>
										<a href="<?php the_permalink(); ?>" > <?php the_post_thumbnail('recent-image'); ?></a>
										
										<p><?php excerpt(20,"বিস্তারিত>>"); ?></p>
										
									</li>
									<?php }
									wp_reset_postdata();
								?>
								<?php } ?>
							</ul>
						</div>
					</div>
					<div class="col-md-3 fix-padding">
						<?php dynamic_sidebar('sidebar_two'); ?>
					</div>
				</div>
			</div>
		</section>
		<!-- Recent NEWS -->
		<section class="single-three">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-one">
						<div class="single-box">
							<div class="title">
							<?php $single1 = ot_get_option('first_single_one');
							$cat_name = "";
							$cat_id = $single1;
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
								<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							</div>
								<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
								<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
								?>
								<?php $count = 0; ?>
								<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
										<div class="first-child">
											<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
											<a href="<?php the_permalink();?>"><?php the_post_thumbnail('recent-image'); ?></a>
											<p><?php excerpt(30,"বিস্তারিত>>"); ?></p>
											</div>
									<?php }else{ ?>
									<ul>
										<li><a href="<?php the_permalink(); ?> ">   <?php the_title(); ?> </a></li>
									</ul>
									<?php } ?>
									
								<?php $count++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							<span class="cat-details">
								<?php 
									$cat_link =  get_category_link( $cat_id );
								?><a href="<?php echo esc_url( $cat_link ); ?>" title="Category Name"><?php echo $cat_name; ?> বিস্তারিত>></a>
							</span>
						</div>
					</div>
					<div class="col-md-4 col-two">
						<div class="single-box">
							<div class="title">
							<?php $single1 = ot_get_option('first_single_two');
							$cat_name = "";
							$cat_id = $single1;
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
								<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							</div>
								<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
								<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
								?>
								<?php $count = 0; ?>
								<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
										<div class="first-child" title="<?php the_title(); ?>">
											<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
											<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('recent-image'); ?></a>
											<p><?php excerpt(20,"বিস্তারিত>>"); ?></p>
											</div>
									<?php }else{ ?>
									<ul>
										<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
									</ul>
									<?php } ?>
									
								<?php $count++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							<span class="cat-details">
								<?php 
									$cat_link =  get_category_link( $cat_id );
								?><a href="<?php echo esc_url( $cat_link ); ?>" title="Category Name"><?php echo $cat_name; ?> বিস্তারিত>></a>
							</span>
						</div>
					</div>
					<div class="col-md-4 col-three">
						<div class="single-box">
							<div class="title">
							<?php $single1 = ot_get_option('first_single_three');
							$cat_name = "";
							$cat_id = $single1;
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
								<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							</div>
								<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
								<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
								?>
								<?php $count = 0; ?>
								<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
										<div class="first-child">
											<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
											<a href="<?php the_permalink();  ?>"><?php the_post_thumbnail('recent-image'); ?></a>
											<p><?php excerpt(20,"বিস্তারিত>>"); ?></p>
											</div>
									<?php }else{ ?>
									<ul>
										<li><a href="<?php the_permalink();  ?>"><?php the_title(); ?></a></li>
									</ul>
									<?php } ?>
									
								<?php $count++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							<span class="cat-details">
								<?php 
									$cat_link =  get_category_link( $cat_id );
								?><a href="<?php echo esc_url( $cat_link ); ?>" title="Category Name"><?php echo $cat_name; ?> বিস্তারিত>></a>
							</span>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Single Three -->
		<section class="mega-news">
			<div class="container">
				<div class="row">
				<?php $single1 = ot_get_option('mega_news_one');
					$cat_name = "";
					if($single1 != ""){
						$cat_name = get_the_category_by_ID($single1);
					}
				?>
					<div class="title"><span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span></div>
					<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
					<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
					?>
					<?php $count = 0; ?>
					<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
									
										<div class="col-md-6">
											<div class="mega-pic">
											<?php $post_id = get_the_ID(); ?>
											<?php if( has_post_thumbnail( $post_id )){ ?>
												<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('mega-image'); ?></a>
											<?php }else{ ?>
												<a href="<?php the_permalink(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/mega.jpg" alt="<?php the_title(); ?>" /></a>
											<?php } ?>
												<div class="mega-cap">
													<h2> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> </h2>
												</div>
											</div>
										</div>
										<div class="col-md-3">
											<div class="mega-list">
												<ul>
											<?php }else{ ?>
											<li>
												<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?> </a></h2>
												<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
												<p><?php excerpt(10,"বিস্তারিত>>"); ?>
												</p>
											</li>	
											<?php } ?>
											
								<?php $count++; }
									wp_reset_postdata();
								?>
							</ul>
					<?php } ?>
						</div>
					</div>
					
		
					<div class="col-md-3">
						<div class="adlist">
						<?php
							$ads1 = ot_get_option('mega_one_right');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Mega NEWS -->
		<section class="ads">
			<div class="container">
				<div class="row">				
					<div class="col-md-4">
						<?php
							$ads1 = ot_get_option('single_one');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
					<div class="col-md-4">
						<?php
							$ads1 = ot_get_option('single_two');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
					<div class="col-md-4">
						<?php
							$ads1 = ot_get_option('single_three');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
				</div>
			</div>
		</section>
		<!-- Ads line two-->
		<section class="single-three">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-one">
						<div class="single-box">
							<div class="title">
							<?php $single1 = ot_get_option('secound_single_one');
							$cat_name = "";
							$cat_id = $single1;
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
								<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							</div>
								
								<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
								<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
								?>
								<?php $count = 0; ?>
								<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
										<div class="first-child">
											<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
											<?php the_post_thumbnail('recent-image'); ?>
											<p><?php excerpt(20,"বিস্তারিত>>"); ?></p>
											</div>
									<?php }else{ ?>
									<ul>
										<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
									</ul>
									<?php } ?>
									
								<?php $count++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							<span class="cat-details">
								<?php 
									$cat_link =  get_category_link( $cat_id );
								?><a href="<?php echo esc_url( $cat_link ); ?>" title="Category Name"><?php echo $cat_name; ?> বিস্তারিত>></a>
							</span>	
						</div>
					</div>
					<div class="col-md-4 col-two">
						<div class="single-box">
							<div class="title">
							<?php $single1 = ot_get_option('secound_single_two');
							$cat_name = "";
							$cat_id = $single1;
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
								<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							</div>
								<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
								<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
								?>
								<?php $count = 0; ?>
								<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
										<div class="first-child">
											<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
											<?php the_post_thumbnail('recent-image'); ?>
											<p><?php excerpt(20,"বিস্তারিত>>"); ?></p>
											</div>
									<?php }else{ ?>
									<ul>
										<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
									</ul>
									<?php } ?>
									
								<?php $count++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							<span class="cat-details">
								<?php 
									$cat_link =  get_category_link( $cat_id );
								?><a href="<?php echo esc_url( $cat_link ); ?>" title="Category Name"><?php echo $cat_name; ?> বিস্তারিত>></a>
							</span>		
						</div>
					</div>
					<div class="col-md-4 col-three">
						<div class="single-box">
							<div class="title">
							<?php $single1 = ot_get_option('secound_single_three');
							$cat_name = "";
							$cat_id = $single1;
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
								<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							</div>
								<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
								<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
								?>
								<?php $count = 0; ?>
								<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
										<div class="first-child">
											<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
											<?php the_post_thumbnail('recent-image'); ?>
											<p><?php excerpt(20, "বিস্তারিত>>"); ?></p>
											</div>
									<?php }else{ ?>
									<ul>
										<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
									</ul>
									<?php } ?>
									
								<?php $count++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							<span class="cat-details">
								<?php 
									$cat_link =  get_category_link( $cat_id );
								?><a href="<?php echo esc_url( $cat_link ); ?>" title="Category Name"><?php echo $cat_name; ?> বিস্তারিত>></a>
							</span>		
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Single three two -->
		<section class="ads">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<?php
							$ads1 = ot_get_option('galary_top_one');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
					<div class="col-md-4">
						<?php
							$ads1 = ot_get_option('galary_top_two');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
					<div class="col-md-4">
						<?php
							$ads1 = ot_get_option('galary_top_three');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
				</div>
			</div>
		</section>
		<!-- Ads line three -->
		<section class="galary">
			<div class="container">
				<div class="row">
					<div class="col-md-2">
						<div class="photo-news">
						<?php $single1 = ot_get_option('galary_left_one');
							$cat_name = "";
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
						?>
							<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
							<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 1
										);
									$query3 = new WP_Query( $args );		
							?>
							<?php while ( $query3->have_posts() ) {
									$query3->the_post();
									?>
									<?php the_post_thumbnail(); ?>
							<?php }
								wp_reset_postdata();
							?>
						<?php } ?>
						</div>
						<div class="photo-news">
						<?php $single1 = ot_get_option('galary_left_two');
							$cat_name = "";
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
						?>
							<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
							<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 1
										);
									$query3 = new WP_Query( $args );		
							?>
							<?php while ( $query3->have_posts() ) {
									$query3->the_post();
									?>
									<?php the_post_thumbnail(); ?>
							<?php }
								wp_reset_postdata();
							?>
						<?php } ?>
						</div>
						<div class="photo-news">
						<?php $single1 = ot_get_option('galary_left_three');
							$cat_name = "";
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
						?>
							<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
							<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 1
										);
									$query3 = new WP_Query( $args );		
							?>
							<?php while ( $query3->have_posts() ) {
									$query3->the_post();
									?>
									<?php the_post_thumbnail(); ?>
							<?php }
								wp_reset_postdata();
							?>
						<?php } ?>
						</div>
					</div>
					<div class="col-md-8">
						<div class="galary-slider">
							<h2><a href=""> ছবি ঘর </a></h2>
							<div class="galary-flexslider">
							  <ul class="slides">
								<?php $recent = ot_get_option('galary_mega'); ?>
							<?php if( $recent != "" ){ 
									$recent = get_the_category_by_ID($recent); ?>
									<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$recent.'',
											'posts_per_page' => 5
										);
									$query = new WP_Query( $args );
													
									?>
									<?php while ( $query->have_posts() ) {
									$query->the_post();
									?>
										<li>
											<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
											<figcaption class="galary-cap">
											<a href="<?php the_permalink(); ?>"><?php the_title();?> </a>
											</figcaption>
										</li>
									<?php }
									wp_reset_postdata();
								?>
								<?php }else{
									global $post;
									$args = array( 'posts_per_page' => 6, 'post_type'=>'galary' );			
													
									$myposts = get_posts( $args );
									foreach( $myposts as $post ) : setup_postdata($post); 	
									
									?>			
										<li>
											<img src="<?php $slide_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'slider-image' ); echo $slide_image[0]; ?>" alt="Galary Images"/>
											<figcaption class="galary-cap">
											<a href="<?php the_permalink(); ?>"><?php the_title();?> </a>
											</figcaption>
										</li>
									<?php endforeach; }
								?>
							  </ul>
							</div>
							
							<div class="custom-navigation">
							  <a href="#" class="flex-prev glyphicon glyphicon-menu-left">  </a>
							  <div class="custom-controls-container"></div>
							  <a href="#" class="flex-next glyphicon glyphicon-menu-right">  </a>
							</div>
						</div>
					</div>
					<div class="col-md-2 galary-right">
						<div class="photo-news">
						<?php $single1 = ot_get_option('galary_right_one');
							$cat_name = "";
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
						?>
							<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
							<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 1
										);
									$query3 = new WP_Query( $args );		
							?>
							<?php while ( $query3->have_posts() ) {
									$query3->the_post();
									?>
									<?php the_post_thumbnail(); ?>
							<?php }
								wp_reset_postdata();
							?>
						<?php } ?>
						</div>
						<div class="photo-news">
						<?php $single1 = ot_get_option('galary_right_two');
							$cat_name = "";
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
						?>
							<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
							<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 1
										);
									$query3 = new WP_Query( $args );		
							?>
							<?php while ( $query3->have_posts() ) {
									$query3->the_post();
									?>
									<?php the_post_thumbnail(); ?>
							<?php }
								wp_reset_postdata();
							?>
						<?php } ?>
						</div>
						<div class="photo-news">
						<?php $single1 = ot_get_option('galary_right_three');
							$cat_name = "";
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
						?>
							<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
							<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 1
										);
									$query3 = new WP_Query( $args );		
							?>
							<?php while ( $query3->have_posts() ) {
									$query3->the_post();
									?>
									<?php the_post_thumbnail(); ?>
							<?php }
								wp_reset_postdata();
							?>
						<?php } ?>
						</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section class="ads">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<?php
							$ads1 = ot_get_option('single_four');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
					<div class="col-md-4">
						<?php
							$ads1 = ot_get_option('single_five');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
					<div class="col-md-4">
						<?php
							$ads1 = ot_get_option('single_six');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
				</div>
			</div>
		</section>
		<!-- Ads line three -->
		<!-- Galary section -->
		<section class="single-three">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-one">
						<div class="single-box">
							<div class="title">
							<?php $single1 = ot_get_option('three_single_one');
							$cat_name = "";
							$cat_id = $single1;
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
								<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							</div>
								
								<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
								<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
								?>
								<?php $count = 0; ?>
								<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
										<div class="first-child">
											<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
											<?php the_post_thumbnail('recent-image'); ?>
											<p><?php excerpt(20,"বিস্তারিত>>"); ?></p>
											</div>
									<?php }else{ ?>
									<ul>
										<li><a href=""><?php the_title(); ?></a></li>
									</ul>
									<?php } ?>
									
								<?php $count++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							<span class="cat-details">
								<?php 
									$cat_link =  get_category_link( $cat_id );
								?><a href="<?php echo esc_url( $cat_link ); ?>" title="Category Name"><?php echo $cat_name; ?> বিস্তারিত>></a>
							</span>	
						</div>
					</div>
					<div class="col-md-4 col-two">
						<div class="single-box">
							<div class="title">
							<?php $single1 = ot_get_option('third_single_two');
							$cat_name = "";
							$cat_id = $single1;
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
								<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							</div>
								<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
								<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
								?>
								<?php $count = 0; ?>
								<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
										<div class="first-child">
											<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
											<?php the_post_thumbnail('recent-image'); ?>
											<p><?php excerpt(20,"বিস্তারিত>>"); ?></p>
											</div>
									<?php }else{ ?>
									<ul>
										<li><a href=""><?php the_title(); ?></a></li>
									</ul>
									<?php } ?>
									
								<?php $count++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							<span class="cat-details">
								<?php 
									$cat_link =  get_category_link( $cat_id );
								?><a href="<?php echo esc_url( $cat_link ); ?>" title="Category Name"><?php echo $cat_name; ?> বিস্তারিত>></a>
							</span>	
						</div>
					</div>
					<div class="col-md-4 col-three">
						<div class="single-box">
							<div class="title">
							<?php $single1 = ot_get_option('third_single_three');
							$cat_name = "";
							$cat_id = $single1;
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
								<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							</div>
								<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
								<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
								?>
								<?php $count = 0; ?>
								<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
										<div class="first-child">
											<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
											<?php the_post_thumbnail('recent-image'); ?>
											<p><?php excerpt(20,"বিস্তারিত>>"); ?></p>
											</div>
									<?php }else{ ?>
									<ul>
										<li><a href=""><?php the_title(); ?></a></li>
									</ul>
									<?php } ?>
									
								<?php $count++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							<span class="cat-details">
								<?php 
									$cat_link =  get_category_link( $cat_id );
								?><a href="<?php echo esc_url( $cat_link ); ?>" title="Category Name"><?php echo $cat_name; ?> বিস্তারিত>></a>
							</span>	
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Single three three -->
		<section class="mega-news">
			<div class="container">
				<div class="row">
				<?php $single1 = ot_get_option('mega_news_two');
					$cat_name = "";
					if($single1 != ""){
						$cat_name = get_the_category_by_ID($single1);
					}
				?>
					<div class="title"><span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span></div>
					<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
					<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
					?>
					<?php $count = 0; ?>
					<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
									
										<div class="col-md-6">
											<div class="mega-pic">
												<?php $post_id = get_the_ID(); ?>
											<?php if( has_post_thumbnail( $post_id )){ ?>
												<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('mega-image'); ?></a>
											<?php }else{ ?>
												<a href="<?php the_permalink(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/mega.jpg" alt="<?php the_title(); ?>" /></a>
											<?php } ?>
												<div class="mega-cap">
													<h2> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> </h2>
												</div>
											</div>
										</div>
										<div class="col-md-3">
											<div class="mega-list">
												<ul>
											<?php }else{ ?>
											<li>
												<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?> </a></h2>
												<?php the_post_thumbnail(); ?>
												<p><?php excerpt(10,"বিস্তারিত>>"); ?>
												</p>
											</li>	
											<?php } ?>
											
								<?php $count++; }
									wp_reset_postdata();
								?>
							</ul>
					<?php } ?>
						</div>
					</div>
					
		
					<div class="col-md-3">
						<div class="adlist">
							<?php
							$ads1 = ot_get_option('mega_two_right');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section class="ads">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<?php
							$ads1 = ot_get_option('single_seven');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
					<div class="col-md-4">
						<?php
							$ads1 = ot_get_option('single_eight');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
					<div class="col-md-4">
						<?php
							$ads1 = ot_get_option('single_nine');
						?>
						<?php if($ads1 != "" ){ ?>
							<img src="<?php echo $ads1; ?>" alt="" />
						<?php } ?>
					</div>
				</div>
			</div>
		</section>
		<!-- Ads line four -->
		<!-- mega news two -->
		<section class="single-three">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-one">
						<div class="single-box">
							<div class="title">
							<?php $single1 = ot_get_option('fourth_single_one');
							$cat_name = "";
							$cat_id = $single1;
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
								<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							</div>
								<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
								<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
								?>
								<?php $count = 0; ?>
								<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
										<div class="first-child">
											<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
											<?php the_post_thumbnail('recent-image'); ?>
											<p><?php excerpt(20,"বিস্তারিত>>"); ?></p>
											</div>
										</li>
									<?php }else{ ?>
									<ul>	
										<li><a href=""><?php the_title(); ?></a></li>
									</ul>
									<?php } ?>
									
								<?php $count++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							<span class="cat-details">
								<?php 
									$cat_link =  get_category_link( $cat_id );
								?><a href="<?php echo esc_url( $cat_link ); ?>" title="Category Name"><?php echo $cat_name; ?> বিস্তারিত>></a>
							</span>	
						</div>
					</div>
					<div class="col-md-4 col-two">
						<div class="single-box">
							<div class="title">
							<?php $single1 = ot_get_option('fourth_single_two');
							$cat_name = "";
							$cat_id = $single1;
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
								<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							</div>
								<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
								<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
								?>
								<?php $count = 0; ?>
								<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
										<div class="first-child">
											<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
											<?php the_post_thumbnail('recent-image'); ?>
											<p><?php excerpt(20,"বিস্তারিত>>"); ?></p>
											</div>
									<?php }else{ ?>
									<ul>
										<li><a href=""><?php the_title(); ?></a></li>
									</ul>
									<?php } ?>
									
								<?php $count++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							<span class="cat-details">
								<?php 
									$cat_link =  get_category_link( $cat_id );
								?><a href="<?php echo esc_url( $cat_link ); ?>" title="Category Name"><?php echo $cat_name; ?> বিস্তারিত>></a>
							</span>	
						</div>
					</div>
					<div class="col-md-4 col-three">
						<div class="single-box">
							<div class="title">
							<?php $single1 = ot_get_option('fourth_single_three');
							$cat_name = "";
							$cat_id = $single1;
							if($single1 != ""){
								$cat_name = get_the_category_by_ID($single1);
							}
							?>
								<span><h2><a href="<?php echo esc_url( get_category_link( $cat_id )); ?>"><?php echo $cat_name; ?></a></h2></span>
							</div>
								<?php if($single1 !="" ){ ?>
								<?php $single1=get_the_category_by_ID($single1); ?>
								<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$single1.'',
											'posts_per_page' => 4
										);
									$query5 = new WP_Query( $args );		
								?>
								<?php $count = 0; ?>
								<?php while ( $query5->have_posts() ) {
									$query5->the_post();
									?>
									<?php if($count == 0){ ?>
										<div class="first-child">
											<h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h2>
											<?php the_post_thumbnail('recent-image'); ?>
											<p><?php excerpt(20,"বিস্তারিত>>"); ?></p>
											</div>
									<?php }else{ ?>
									<ul>
										<li><a href=""><?php the_title(); ?></a></li>
									</ul>
									<?php } ?>
									
								<?php $count++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							<span class="cat-details">
								<?php 
									$cat_link =  get_category_link( $cat_id );
								?><a href="<?php echo esc_url( $cat_link ); ?>" title="Category Name"><?php echo $cat_name; ?> বিস্তারিত>></a>
							</span>	
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Single three four -->
		 <?php get_template_part('footer-carousel'); ?>
		<!-- News Carousel -->
	<?php get_footer(); ?>