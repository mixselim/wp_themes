<section class="top-news">
			<div class="container">
				<div class="row">
				<?php $cat_top = ot_get_option('top_news_cat');?>
				<?php if( $cat_top != "" ){ ?>
				<?php $cat_top=get_the_category_by_ID($cat_top); ?>
						<?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$cat_top.'',
											'posts_per_page' => 4
										);
							$query = new WP_Query( $args );
													
						?>
						<?php 
						$c=1;
						while ( $query->have_posts() ) {
							$query->the_post();
							?>
							<div class="col-md-3 <?php if($c==4){ echo "fix-padding"; } ?>">
								<div class="top-box">
									<div class="topbox-con" title="<?php the_title(); ?>">
										<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
										<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'top-image' ); ?></a>
										<p> <?php excerpt(7,"বিস্তারিত>>"); ?> </p>
									</div>
								</div>
							</div>
							<?php $c++; }
							wp_reset_postdata();
						?>
					<?php } ?>
				</div>
			</div>
		</section>