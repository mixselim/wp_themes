<section class="news-carousel">
			<div class="container">
				<div class="row">
					<div class="carousel-wrap">
						<div class="flexslider">
						  <ul class="slides">
						  <?php $rarousel = ot_get_option('foter_carousel'); ?>
						  <?php if($rarousel !=""){ ?>
						  <?php $rarousel = get_the_category_by_ID($rarousel); ?>

						  <?php $args = array(
											'post_type' => 'post',
											'category_name' => ''.$rarousel.'',
											'posts_per_page' => -1
										);
									$query3 = new WP_Query( $args );		
							?>
							<?php while ( $query3->have_posts() ) {
									$query3->the_post();
									?>
									<li>
									<?php the_post_thumbnail('carousel-image'); ?>
									<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
									</li>
							<?php }
								wp_reset_postdata();
							?>
							<?php } ?>
							<!-- items mirrored twice, total of 12 -->
						  </ul>
						</div>
					</div>
				</div>
			</div>
			
		</section>