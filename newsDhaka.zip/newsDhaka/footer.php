<footer class="footer">
			<section id="footer-nav">
				<div class="container">
					<div class="row">
						<div class="f-nav">
							<?php wp_nav_menu( array( 'theme_location' => 'footer-menu')); ?>
						</div>
					</div>
				</div>
			</section>
			<!-- Footer Navigation -->
			<section class="footer-middle">
				<div class="container">
					<div class="row">
						<?php dynamic_sidebar('footer_top'); ?>
					</div>
				</div>
			</section>
			<!-- Footer Middle -->
			<section class="footer-bottom">
				<div class="container">
					<div class="row">
						<div class="col-md-3">
							<?php dynamic_sidebar('footer_aria_one'); ?>
						</div>
						<div class="col-md-3">
							<?php dynamic_sidebar('footer_aria_two'); ?>
						</div>
						<div class="col-md-3">
							<?php dynamic_sidebar('footer_aria_three'); ?>
						</div>
						<div class="col-md-3">
							<?php dynamic_sidebar('footer_aria_four'); ?>
						</div>
					</div>
				</div>
				
			</section>
			<!-- Footer Bottom -->
		</footer>
	</div>
	<div class="info-wrap">
			<div class="bottom-info">
		<div class="bottom-left">
			<div class="left-up">
				<img src="<?php echo get_template_directory_uri(); ?>/img/info.gif" alt="" />
			</div>
			<div class="left-down">
				<?php
							$logo = ot_get_option('footer_call');
						?>
						<?php if($logo != "" ){ ?>
							<a href="<?php bloginfo('home'); ?>"><img src="<?php echo $logo; ?>" alt="<?php bloginfo('name'); ?>" /></a>
						<?php }else {?>
						<img src="<?php echo  get_template_directory_uri(); ?>/img/ticker.gif" alt="" />
				<?php } ?>
				
			</div>
		</div>
		<div class="bottom-right">
			<div class="right-up">
				<div class="middle">
					<ul class="bxslider">
					  <?php
								$bcat = ot_get_option('foter_tslid');
							?>
							<?php if($bcat != ""){?>
								<?php 
								$bcat = get_the_category_by_ID($bcat);
										$args = array(
											'post_type' => 'post',
											'category_name' => ''.$bcat.'',
											'posts_per_page' => 4
										);
									$query = new WP_Query( $args );
								?>
									
									<?php
									while ( $query->have_posts() ) {
									$query->the_post();
									?>
									
											<li style="float: none; list-style: outside none none; position: relative; width: 499px;">
												<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
											</li>
									<?php }
									wp_reset_postdata();
								?>
								<?php } ?>
					</ul>
				</div>
				<div class="bottom-logo">
					<?php
							$logo = ot_get_option('footer_logo');
						?>
						<?php if($logo != "" ){ ?>
							<a href="<?php bloginfo('home'); ?>"><img src="<?php echo $logo; ?>" alt="<?php bloginfo('name'); ?>" /></a>
						<?php }else {?>
						<img src="<?php echo get_template_directory_uri(); ?>/img/logo.png" alt="" />
				<?php } ?>
					
				</div>
			</div>
			<div class="bottom-down">
				<div class="footer-slide">
					<ul id="webticker-footer" data-duration="20" data-loop="2" data-effect="linear" >
							<?php
								$bcat = ot_get_option('foter_bslid');
							?>
							<?php if($bcat != ""){?>
								<?php 
								$bcat = get_the_category_by_ID($bcat);
										$args = array(
											'post_type' => 'post',
											'category_name' => ''.$bcat.'',
											'posts_per_page' => 4
										);
									$query = new WP_Query( $args );
								?>
									
									<?php
										$c = '1';
									while ( $query->have_posts() ) {
									$query->the_post();
									?>
									
											<li id='<?php echo "item".$c; ?>' >
											<a href="<?php the_permalink(); ?>"> <?php the_title(); ?></a>
											</li>
									<?php $c++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							</ul>
				
				</div>
			</div>
		</div>
	
	</div>
	
	</div>
	<!-- ============ JavaScripts ================ -->
	
	<!-- JQueury -->
	<!-- Breaking News -->
	<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.webticker.js"></script>
	</script>
	<!-- Bootstrap minified JavaScript -->
	<script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script>
	<!-- Slider Footer FIxed -->
	<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.bxslider.min.js"></script>
	<!--   Active Bootstrap Tab   -->
	<script type="text/javascript">
		jQuery('#myTabs a').click(function (e) {
		  e.preventDefault()
		  jQuery(this).tab('show')
		});
		
		jQuery('#myTabs a[href="#profile"]').tab('show') // Select tab by name
		jQuery('#myTabs a:first').tab('show') // Select first tab
		jQuery('#myTabs a:last').tab('show') // Select last tab
		jQuery('#myTabs li:eq(2) a').tab('show') // Select third tab (0-indexed)
	</script>
	<!-- Flexi script -->
	<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.flexslider.js"></script>
	<!-- Main Flexi Slier Active -->
	<script type="text/javascript">
                jQuery(function(){
                    SyntaxHighlighter.all();
                });
		jQuery(window).load(function() {
		  jQuery('.main-flexslider').flexslider({
			animation: "slide",
			controlNav: false,
			start: function(slider){
        			jQuery('body').removeClass('loading');
      			}
		  });
		});
	</script>
	<!-- Galary Flexi Slider -->
	<script type="text/javascript">
                jQuery(function(){
                  SyntaxHighlighter.all();
                });
		jQuery(window).load(function() {
		  jQuery('.galary-slider').flexslider({
			animation: "slide",
			controlNav: false,
			controlsContainer: jQuery(".custom-controls-container"),
			customDirectionNav: jQuery(".custom-navigation a"),
                        start: function(slider){
                          jQuery('body').removeClass('loading');
                        }
		  });
		});
	</script>
	<!-- Flexi Carousel Active -->
	<script type="text/javascript">
		
		(function() {
 
		  // store the slider in a local variable
		  var $window = jQuery(window),
			  flexslider;
		 
		  // tiny helper function to add breakpoints
		  function getGridSize() {
			return (window.innerWidth < 600) ? 2 :
				   (window.innerWidth < 900) ? 3 : 4;
		  }
		 
		  jQuery(function() {
			SyntaxHighlighter.all();
		  });
		 
		  jQuery(window).load(function() {
			jQuery('.flexslider').flexslider({
			  animation: "slide",
			  animationLoop: true,
			  itemWidth: 400,
			  itemMargin: 0,
			  controlNav: false,
			  minItems: getGridSize(
			  ), // use function to pull in initial value
			  maxItems: getGridSize() // use function to pull in initial value
			});
		  });
		 
		  // check grid size on resize event
		  jQuery(window).resize(function() {
			var gridSize = getGridSize();
		 
			flexslider.vars.minItems = gridSize;
			flexslider.vars.maxItems = gridSize;
		  });
		}());
	</script>
	<!-- Flexi Category slider Active -->
	<script type="text/javascript">
		jQuery(window).load(function() {
		  jQuery('.cat-flexslider').flexslider({
			animation: "slide",
			controlNav: true
		  });
		});
	</script>
	
	<!-- breaking news Active -->
	<script type="text/javascript">
		jQuery(window).load(function(){
			jQuery("#webticker").webTicker();
		});
	</script>
	<!-- breaking news Footer Active -->
	<script type="text/javascript">
		jQuery(window).load(function(){
			jQuery("#webticker-footer").webTicker();
		});
	</script>
	<!-- Menu Strick -->
	<script type="text/javascript">
		jQuery(window).load(function() {
			var s = jQuery("#main-nav");
			var pos = s.position();                   
			jQuery(window).scroll(function() {
				var windowpos = jQuery(window).scrollTop();
				if (windowpos > pos.top) {
					s.addClass("stick");
					
				} else {
					s.removeClass("stick");
				}
			});
		});
	</script>
	<!-- Breaking title Menu Strick -->
	<script type="text/javascript">
		jQuery(window).load(function() {
			var s = jQuery(".breaking-title");
			var pos = s.position();                   
			jQuery(window).scroll(function() {
				var windowpos = jQuery(window).scrollTop();
				if (windowpos > pos.top) {
					s.addClass("stick1");
				} else {
					s.removeClass("stick1");
				}
			});
		});
	</script>
	<!-- Breaking News Strick -->
	<script type="text/javascript">
		jQuery(window).load(function() {
			var s = jQuery(".breaking-content");
			var pos = s.position();                   
			jQuery(window).scroll(function() {
				var windowpos = jQuery(window).scrollTop();
				if (windowpos > pos.top) {
					s.addClass("stick2");
				} else {
					s.removeClass("stick2");
				}
			});
		});
	</script>
	<!-- mobile Menu Strick -->
	<script type="text/javascript">
		jQuery(window).load(function() {
			var s = jQuery(".mobile-menu");
			var pos = s.position();                   
			jQuery(window).scroll(function() {
				var windowpos = jQuery(window).scrollTop();
				if (windowpos > pos.top) {
					s.addClass("stick");
				} else {
					s.removeClass("stick");
				}
			});
		});
	</script>
	<!-- Active Fixed Footer slider -->
	<script type="text/javascript">
		jQuery(window).load(function(){
		  jQuery('.bxslider').bxSlider({
			auto: true,
			mode: 'vertical'
		  });
		   
		});
	</script>
	<!-- Test -->
	 <script src="<?php echo get_template_directory_uri(); ?>/js/tinynav.min.js"></script>
	<script>
    jQuery(window).load(function () {

      // TinyNav.js 1
      jQuery('#nav').tinyNav({
        active: 'selected',
        indent: '→',
        label: 'Menu'
      });

    });
  </script>
	 
	<?php wp_footer(); ?>
	</body>
</html>