<?php get_header(); ?>
		<!-- header -->		
<!-- =================== Header =================== -->
		<div class="cat-page">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="cat-slider">
							<div class="cat-flexslider">
							  <ul class="slides">
							  
									<?php 
									$count = 1;
									while ( have_posts() ) {
										the_post();
										if( $count > 5)
										{
											break;
										}
									?>
									<li class="slide-content">
										<?php if(has_post_thumbnail( $post_id )){?>
										<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('slider-image'); ?></a>
										<?php }else { ?>
										<h2><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h2>
										<p><?php excerpt(30, "বিস্তারিত>>"); ?></p>
										
										<?php } ?>
									</li>

									<?php $count++; }
									wp_reset_postdata();
								?>
								
							  </ul>
							</div>
						</div>
						<div class="breadcumbs">
							<?php if ( function_exists('wordpress_breadcrumbs') ) wordpress_breadcrumbs(); ?>
						</div>
						<div class="daCatwrap">
								<?php
										$catCaount = 1;
									while ( have_posts() ) {
										the_post();
									?>
										<?php if($catCaount > 2){?>
											<div class="dCat">
												<a href="<?php the_permalink(); ?>">
													<h2> <?php the_title(); ?> </h2>
													<?php the_post_thumbnail(); ?>
												</a>
												<?php excerpt(16, "বিস্তারিত>>"); ?>
											</div>
										<?php } ?>
										
									<?php $catCaount++; }
									wp_reset_postdata();
								?>
						</div>
						
						<div class="cat-pagi">
							<div class="news-navi">
								<div class="next-news">
									<?php next_posts_link( __( '<span class="meta-nav"></span> Next') ); ?>
								</div>
								<div class="prev-news"><?php previous_posts_link( __( 'Prev<span class="meta-nav"></span>') ); ?></div>
							
							</div>
							<div class="bclear"></div>
							<div class="newsSelect">
								<div class="selectHead">
									আপনার এলাকার সংবাদ দেখুন।
								</div>
								<div class="selevtAria">
									<label>পড়তে চাই: </label>
									
								</div>
								<div class="select-news" title="select news">
								<select name="sclt1" id="sclt1" onchange="cat_change( this.id,'sclt2')" >
									<option value=""> </option>
									<option id="sylhet" value="sylhet">Sylhet</option>
									<option id="dhaka" value="dhaka">Dhaka</option>
									<option id="chittagong" value="chittagong">Chittagong</option>
									<option id="rajshahi" value="rajshahi"> Rajshahi </option>
									<option id="khulna" value="khulna"> Khulna </option>
									<option id="barishal" value="barishal"> Barishal </option>
									<option id="rangpur" value="rangpur"> Rangpur </option>
									<option id="mahmangshing" value="mahmangshing"> Maymangshing </option>
								</select>
								<select name="sclt2" id="sclt2" onchange="onCatChange(this.id,'sclt1')">
								
								</select>
								</div>
							</div>
						</div>
						<!-- CatBox -->
					</div>
					<div class="col-md-3">
						<div class="news-last">
							<h3> সর্বশেষ </h3>
							<ul>
					
									<?php 
										$count = 1;
									while ( have_posts() ) {
											the_post();
											if($count >5)
											{
												break;
											}
									?>
									<li>
										<a href="<?php the_permalink(); ?>">
											<?php the_post_thumbnail(); ?>
											<?php excerpt(10,"বিস্তারিত>>"); ?>
										</a>
									</li>

									<?php $count++; }
									wp_reset_postdata();
								?>
								
							</ul>
							
						</div>
					</div>
				</div>
			</div>	
		</div>
<!-- ========== Footer Slider ========== -->
	 <?php get_template_part('footer-carousel'); ?>
		<!-- News Carousel -->
	<?php get_footer(); ?>