<!DOCYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
		<?php
			$fcon = ot_get_option('favi_con');
		?>
		<?php if($fcon != "" ){ ?>
			<link rel="shortcut icon" href="<?php echo $fcon; ?>" >
		<?php }else {?>
			<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/favicon.ico" >
		<?php } ?>
		<title><?php bloginfo('name'); ?><?php wp_title(); ?></title>
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
		<!-- Bootstrap minified CSS -->
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css" />
		<!-- Bootstrap Optional theme -->
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap-theme.min.css" />
		<!-- flexi Style -->
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/flexslider.css" type="text/css">
		<!-- News scroll -->
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/webticker.css" type="text/css">
		<!-- Footer Fixed Slider -->
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/jquery.bxslider.css" type="text/css">
		<!-- Main css -->
		<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" />
		<!-- Responsive css -->
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/ress.css" />
		<!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js">
			</script>
		<![endif]-->
		<?php wp_head(); ?>
		<script type="text/javascript">
			document.getElementById("test").style.display = "none";
		</script>
		<!-- begin  -->
		<?php  
			$dak[]= "|";
			$terms = get_terms( 'dhaka' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $dak[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$syl[]= "|";
			$terms = get_terms( 'sylhet' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $syl[] = $term->name;
					 }
				 }		
		?>
		
		<?php  
			$chit[] = "|";
			$terms = get_terms( 'chittagong', array('hide_empty' => false) );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $chit[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$raj[]= "|";
			$terms = get_terms( 'rajshahi', array('hide_empty' => false) );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $raj[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$bori[]= "|";
			$terms = get_terms( 'barishal', array('hide_empty' => false) );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $bori[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$kul[]= "|";
			$terms = get_terms( 'khulna' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $kul[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$rang[]= "|";
			$terms = get_terms( 'rangpur' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $rang[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$may[]= "|";
			$terms = get_terms( 'mahmangshing' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $may[] = $term->name;
					 }
				 }		
		?>
		
		
		<!-- End -->
		<!-- Scripts Select news -->
		<script type="text/javascript">
			var parent = "";
			function cat_change( s1,s2){
				var s1 = document.getElementById(s1);
				var s2 = document.getElementById(s2);
				s2.innerHTML = "";
				var opArray = "|"
				if(s1.value == 'sylhet'){
					opArray = [<?php 
						foreach( $syl as $val ){
							?>"<?php echo $val;?>|<?php echo $val;?>",<?php
						}
					?>"|"];
					parent = "sylhet";
				}else if(s1.value == 'dhaka'){
					opArray = [<?php 
						foreach( $dak as $val ){
							?>"<?php echo $val;?>|<?php echo $val;?>",<?php
						}
					?>"|"];
					parent = "dhaka";
				}else if(s1.value == 'chittagong'){
					opArray = [<?php 
						foreach( $chit as $val ){
							?>"<?php echo $val;?>|<?php echo $val;?>",<?php
						}
					?>"|"];
					parent = "chittagong";
				}else if(s1.value == 'rajshahi'){
					opArray = [<?php 
						foreach( $raj as $val ){
							?>"<?php echo $val;?>|<?php echo $val;?>",<?php
						}
					?>"|"];
					parent = "rajshahi";
				}else if(s1.value == 'barishal'){
					opArray = [<?php 
						foreach( $bori as $val ){
							?>"<?php echo $val;?>|<?php echo $val;?>",<?php
						}
					?>"|"];
					parent = "barishal";
				}else if(s1.value == 'khulna'){
					opArray = [<?php 
						foreach( $kul as $val ){
							?>"<?php echo $val;?>|<?php echo $val;?>",<?php
						}
					?>"|"];
					parent = "khulna";
				}else if(s1.value == 'rangpur'){
					opArray = [<?php 
						foreach( $rang as $val ){
							?>"<?php echo $val;?>|<?php echo $val;?>",<?php
						}
					?>"|"];
					parent = "rangpur";
				}else if(s1.value == 'mahmangshing'){
					opArray = [<?php 
						foreach( $may as $val ){
							?>"<?php echo $val;?>|<?php echo $val;?>",<?php
						}
					?>"|"];
					parent = "mahmangshing";
				}
				for(var option in opArray){
					var pair = opArray[option].split("|");
					var newOption = document.createElement("option");
					newOption.value = pair[0];
					newOption.innerHTML = pair[1];
					s2.options.add(newOption);
				}
			}
		</script>
		<!-- javascript two  -->
		<script type="text/javascript">
									<!--
		//var dropdown = document.getElementById("sclt2");
		function onCatChange(t1,t2) {
		var dropdown = document.getElementById(t1);
		var dropdown2 = document.getElementById(t2);
			if ( 1 ) {
				location.href = "<?php echo esc_url( home_url( '/' ) ); ?>/"+parent+"/"+dropdown.options[dropdown.selectedIndex].value;
			}
		}
		-->
								</script>
								
		<!-- theme option css -->

			<?php $title_size = ot_get_option( 'category_title_size' ); 
				$post_title_size = ot_get_option( 'post_title_size' ); 
				$post_font_size = ot_get_option( 'post_font_size' ); 
				$list_title_size = ot_get_option( 'list_title_font_size' ); 
				$read_more_size = ot_get_option( 'read_more_font_size' ); 
				$category_more_size = ot_get_option( 'category_more_font_size' ); 
				$single_title_size = ot_get_option( 'single_title_size' ); 
				$single_post_font_size = ot_get_option( 'single_post_font_size' ); 
				$post_title_color = ot_get_option( 'post_title_color' ); 
				$post_title_hover = ot_get_option( 'post_title_hover' ); 
				$post_text_color = ot_get_option( 'post_text_color' ); 
				$list_title_color = ot_get_option( 'list_title_color' ); 
				$read_more_color = ot_get_option( 'read_more_color' ); 
				$read_more_hover = ot_get_option( 'read_more_hover' ); 
			?>
		<style type="text/css">
			.title h2, .photo-news h2{
				font-size:<?php echo $title_size[0];?>px;
				
			}
			.top-box h2 a, .recent-content ul li h2 a, .first-child h2,.first-child h2 a,.mega-list ul li h2, .mega-list ul li h2 a, .tab-parent ul li a{
				font-size:<?php echo $post_title_size[0]; ?>px;
				color:<?php echo $post_title_color; ?>;
			}.top-box h2 a:hover, .recent-content ul li h2 a:hover, .first-child h2 a:hover, .mega-list ul li h2 a:hover, .tab-parent ul li a:hover{
				color:<?php echo $post_title_hover; ?>;
			}
			.top-box div.topbox-con p, .recent-content ul li p, .first-child p,.mega-list ul li p, .carousel-wrap ul li h2 a{
				font-size:<?php echo $post_font_size[0]; ?>px;
				color:<?php echo $post_text_color; ?>;
			}
			.tab-content ul li a, .single-box ul li a{
				font-size:<?php echo $list_title_size[0]; ?>px;
				color:<?php echo $list_title_color; ?>;
			}
			.tab-content ul li a:hover, .single-box ul li a:hover{
				color:<?php echo $list_title_hover; ?>;
			}
			.readmore{
				font-size:<?php echo $read_more_size[0]; ?>px;
				color:<?php echo $read_more_color; ?>;
			}
			.readmore:hover{
				color:<?php echo  $read_more_hover;?>
			}
			.cat-details{
				font-size:<?php echo $category_more_size[0]; ?>px;
			}
			.single-post h1{
				font-size:<?php echo $single_title_size[0];?>px;
			}
			.single-content p{
				font-size:<?php echo $single_post_font_size[0];?>px;
			
			}
		
		</style>

	</head>
	
	<body>
	<div class="wrapper">
		<header class="header">
			<div class="container">
				<div class="row">
					<div class="col-md-2 bk-fix" >
						<div class="breaking-title">
							<h3>তাজা খবরঃ </h3>
						</div>
					</div>
					<div class="col-md-6 bk-fix">
						<div class="breaking-content fix">
							<!-- first ticker -->
							<ul id="webticker" data-duration="20" data-loop="2" data-effect="linear" >
							<?php
								$bcat = ot_get_option('breaking_news');
							?>
							<?php if($bcat != ""){?>
								<?php 
								$bcat = get_the_category_by_ID($bcat);
										$args = array(
											'post_type' => 'post',
											'category_name' => ''.$bcat.'',
											'posts_per_page' => 4
										);
									$query = new WP_Query( $args );
								?>
									
									<?php
										$c = '1';
									while ( $query->have_posts() ) {
									$query->the_post();
									?>
									
											<li id='<?php echo "item".$c; ?>' >
											<a href="<?php the_permalink(); ?>"> <?php the_title(); ?></a>
											</li>
									<?php $c++; }
									wp_reset_postdata();
								?>
								<?php } ?>
							</ul>
						</div> 
					</div>
					<div class="col-md-4 bk-fix">
						<div id="date" class="fix"> 
								<span> <?php the_time('F j, Y') ?> </span>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4">
						<div class="logo">
						<?php
							$logo = ot_get_option('logo');
						?>
						<?php if($logo != "" ){ ?>
							<a href="<?php bloginfo('home'); ?>"><img src="<?php echo $logo; ?>" alt="<?php bloginfo('name'); ?>" /></a>
						<?php }else {?>
							<img src="<?php echo get_template_directory_uri(); ?>/img/logo.png" alt="logo" />
						<?php } ?>
						</div>
					</div>
					<div class="col-md-6">
						<div class="banner">
						
						</div>
					</div>
				</div>
				<div class="row fix-padding" >
					<div id="main-nav">
							<nav id="sticker" class="fixme">
							<?php wp_nav_menu( array( 'theme_location' => 'main-menu')); ?>
						</nav>
					</div>
					<div class="mobile-menu">
							<?php wp_nav_menu( array( 'theme_location' => 'mobile-menu', 'menu_id' => 'nav', 'container' => false )); ?>
					</div>
					    
				</div>
				</div>
			</div>
		</header>