<?php  
			$syl[]= "|";
			$terms = get_terms( 'sylhet' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $syl[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$dak[]= "|";
			$dak[] = "borishal";
			$terms = get_terms( 'dhaka' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $dak[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$chit[]= "|";
			$terms = get_terms( 'chittagong' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $chit[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$raj[]= "|";
			$terms = get_terms( 'rajshahi' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $raj[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$bori[]= "|";
			$terms = get_terms( 'barishal' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $bori[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$kul[]= "|";
			$terms = get_terms( 'khulna' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $kul[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$rang[]= "|";
			$terms = get_terms( 'rangpur' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $rang[] = $term->name;
					 }
				 }		
		?>
		<?php  
			$may[]= "|";
			$terms = get_terms( 'mahmangshing' );
				 if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					 foreach ( $terms as $term ) {
					    $may[] = $term->name;
					 }
				 }		
		?>
		