<?php get_header(); ?>
		<!-- header -->
<!-- =================== Header =================== -->
		<div class="single-page">
			<div class="container">
				<div class="row">
					<div class="error">
						<h1> 404 Error! </h1>
						<h3> Content Not Found. </h3>
					</div>
				</div>
			</div>
		
		</div>



<!-- ========== Footer Slider ========== -->
	<?php get_footer(); ?>