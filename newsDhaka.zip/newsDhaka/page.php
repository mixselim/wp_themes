<?php get_header(); ?>
		<!-- header -->
		<?php get_template_part('top-news'); ?>
		<!-- TOP NEWS -->
<!-- =================== Header =================== -->
		<div class="single-page">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="breadcumbs">
							<?php if ( function_exists('wordpress_breadcrumbs') ) wordpress_breadcrumbs(); ?>
						</div>
						<?php if(have_posts()) : ?>
					<?php while (have_posts()) : the_post(); ?>
						<div class="single-post">
							<div class="single-date">
								<?php the_time('F j, Y') ?>
							</div>
							<h1> <?php the_title(); ?> </h1>
							<p> <?php the_meta(); ?> </p>
							<div class="single-content">
								<?php the_post_thumbnail(); ?>
								<?php the_content(); ?>

							</div>
						</div>
						<?php endwhile; ?> 						
						<?php else : ?>

						<h3><?php _e('404 Error&#58; Not Found'); ?></h3>
					<?php endif; ?>
						<div class="cat-pagi">
							<div class="newsSelect">
								<div class="selectHead">
									আপনার এলাকার সংবাদ দেখুন।
								</div>
								<div class="selevtAria">
									<label>পড়তে চাই: </label>
									
								</div>
								<div class="select-news" title="select news">
								<select name="sclt1" id="sclt1" onchange="cat_change( this.id,'sclt2')" >
									<option value=""> </option>
									<option id="sylhet" value="sylhet">Sylhet</option>
									<option id="dhaka" value="dhaka">Dhaka</option>
									<option id="chittagong" value="chittagong">Chittagong</option>
									<option id="rajshahi" value="rajshahi"> Rajshahi </option>
									<option id="khulna" value="khulna"> Khulna </option>
									<option id="barishal" value="barishal"> Barishal </option>
									<option id="rangpur" value="rangpur"> Rangpur </option>
									<option id="mahmangshing" value="mahmangshing"> Maymangshing </option>
								</select>
								<select name="sclt2" id="sclt2" onchange="onCatChange(this.id,'sclt1')">
								
								</select>
								</div>
							</div>
						</div>
						<!-- CatBox -->
					</div>
					<div class="col-md-3">
						<div class="news-last">
						<?php
							$category = get_the_category();
							$cat_name = $category[0]->cat_name;
						?>
						<h3><?php echo $cat_name; ?> সর্বশেষ </h3>
						<ul>
						<?php $args = array(
											'post_type' => 'post',
											'category_name' => $cat_name,
											'posts_per_page' => 4
										);
									$query = new WP_Query( $args );
													
									?>
									<?php while ( $query->have_posts() ) {
									$query->the_post();
									?>
										<li>
											<a href="<?php the_permalink(); ?>">
											<?php the_post_thumbnail(); ?>
											<?php excerpt(6,"বিস্তারিত>>"); ?>
											</a>
										</li>
									<?php }
									wp_reset_postdata();
								?>
							</ul>
						</div>
					</div>
				</div>
			</div>
		
		</div>



<!-- ========== Footer Slider ========== -->
			<?php get_template_part('footer-carousel'); ?>
		<!-- News Carousel -->
	<?php get_footer(); ?>