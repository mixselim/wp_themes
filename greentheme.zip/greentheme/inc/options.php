<?php

function modified( $argu ){
	?>
    	<select name="<?php echo $argu;?>" id="">
		<?php
		$terms = get_terms( 'product_cat' );
		if($terms){	 
			foreach( $terms as $category ) {
				?>
				<option <?php if($category->name==get_option($argu)) echo 'selected'; ?> value="<?php echo $category->name; ?>"><?php echo $category->name; ?></option>
				<?php
			}
			
		}	?>
		</select>
    <?php
}

function logo_display()
{
	?>
        <input type="file" name="logo" id="logo" /> 
        <img src="<?php echo get_option('logo'); ?>" width="100" height="75" alt="" />
   <?php
}

function handle_logo_upload()
{
	if(!empty($_FILES["logo"]["tmp_name"]))
	{
		$urls = wp_handle_upload($_FILES["logo"], array('test_form' => FALSE));
	if ($urls["error"]) 
	{
		return $urls["error"];
	}
		$temp = $urls["url"];
		return $temp; 
	} 
	return get_option('logo');
}

function display_slid_one(){			modified('slid_one');			}
function display_slid_two(){				modified('slid_two');				}
function display_slid_three(){				modified('slid_three');				}
function display_slid_four(){		modified('slid_four');		}


function display_theme_panel_fields()
{
	//Settings Sections
	add_settings_section("section", "All Settings", null, "theme-options");
	
	//Settings Fields
	
	add_settings_field("logo", "Logo", "logo_display", "theme-options", "section");
    add_settings_field("slid_one", "Slider Cat One", "display_slid_one", "theme-options", "section");
	add_settings_field("slid_two", "Slider Cat Two", "display_slid_two", "theme-options", "section");
	add_settings_field("slid_three", "Slider Cat Three", "display_slid_three", "theme-options", "section");
	add_settings_field("slid_four", "Slider Cat Four", "display_slid_four", "theme-options", "section");
	
	
	
	//Register Settings
    register_setting("section", "logo", "handle_logo_upload");
	register_setting("section", "slid_one");
    register_setting("section", "slid_two");
    register_setting("section", "slid_three");
    register_setting("section", "slid_four");
	
}

add_action("admin_init", "display_theme_panel_fields");

?>