<?php get_header(); ?>
    <section class="page-container">
        <div class="row margin-top-10px">
            
                <article class="col-sm-8 DetailsContent" style="padding-left: 0;">
						<div class="hidden-print" style="padding-bottom: 10px;">
							
						</div>
												<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

						<h1><?php the_title(); ?></h1>
						<hr>
						<small>
						
						<div class="pull-right hidden-print">
							<a href="#" onclick="fPrint()">
								<i style="color: #2aa3d5" class="fa fa-print fa-2x"></i>
							</a>
						</div>
						</small>
						<br>
						
						<div class="content">
							
							<div style="clear:both;">
								<?php the_content(); ?>	
							</div>
						</div>
						
						<?php endwhile; else : ?>
							<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
						<?php endif; ?>
						<div class="DAdd hidden-print">
							<div class="col-sm-6">
								<!-- Jago adds -->
								
							</div>

							<div class="col-sm-6">
								<!-- Jago adds -->
								
							</div>
						</div>

						
						<!--div class="hidden-print">
							<div class="addthis_relatedposts_inline"></div>
						</div-->

						<div class="DetailsComment hidden-print">
							<h2><!-- comment title --></h2>
							
						</div>

				</article>
				
				
        </div>
    </section>

   <?php get_footer(); ?>