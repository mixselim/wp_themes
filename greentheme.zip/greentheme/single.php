<?php get_header(); ?>
    <section class="container">
        <div class="row margin-top-10px">
            
                <article class="col-sm-8 DetailsContent" style="padding-left: 0;">
						<div class="hidden-print" style="padding-bottom: 10px;">
							
						</div>
						<div class="hidden-print">
							<ol class="breadcrumb">
								<?php custom_breadcrumbs(); ?>
							</ol>	
						</div>
						<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

						<h1><?php the_title(); ?></h1>
						<hr>
						<div <?php post_class(); ?> id="post-<?php the_ID(); ?>" >
							<div class="contentimg">
								<img src="<?php the_post_thumbnail_url(); ?>" title="<?php the_title(); ?>" class="img-responsive">
							</div>
							<div style="clear:both;">
								<?php the_content(); ?>	
							</div>
							<?php get_the_tag_list(); ?>
						</div>
						
						<?php wp_link_pages('before=<div id="page-links">&after=</div>'); ?>
						
						<?php endwhile; else : ?>
							<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
						<?php endif; ?>
						<?php  the_posts_pagination(); ?>

						
						<!--div class="hidden-print">
							<div class="addthis_relatedposts_inline"></div>
						</div-->
						<?php comment_form(); ?>
						<div class="DetailsComment hidden-print">
							<?php comments_template(); ?> 
							
							<?php wp_list_comments(); ?>
							<?php paginate_comments_links(); ?>
						</div>

				</article>
				
				
        </div>
    </section>
   
   <?php get_footer(); ?>