<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


get_header( 'shop' ); ?>

	<?php if( is_shop() ){ ?>
	<?php 
		$slid_cat_one = get_option('slid_one');
		$slid_cat_two = get_option('slid_two');
		$slid_cat_three = get_option('slid_three');
		$slid_cat_four = get_option('slid_four');
	?>
	<div class="banner-slid">
		<div id="mi-slider" class="mi-slider">
					<ul>

					<?php
				        $args = array( 'post_type' => 'product', 'posts_per_page' => 4, 'product_cat' => $slid_cat_one, 'orderby' => 'rand' );
				        $loop = new WP_Query( $args );
				        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
				
				     
				                <li>    
				
				                    <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
				
				                        <?php woocommerce_show_product_sale_flash( $post, $product ); ?>
				
				                        <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
				
				                        <h4><?php the_title(); ?></h4>
				
				                        <span class="price"><?php echo $product->get_price_html(); ?></span>                    
				
				                    </a>
				
				                    <?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
				
				                </li>
				
				    <?php endwhile; ?>
				    <?php wp_reset_query(); ?>
    
    
					

					</ul>
					
					<ul>
					
										<?php
				        $args = array( 'post_type' => 'product', 'posts_per_page' => 4, 'product_cat' => $slid_cat_two, 'orderby' => 'rand' );
				        $loop = new WP_Query( $args );
				        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
				
				     
				                <li>    
				
				                    <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
				
				                        <?php woocommerce_show_product_sale_flash( $post, $product ); ?>
				
				                        <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
				
				                        <h4><?php the_title(); ?></h4>
				
				                        <span class="price"><?php echo $product->get_price_html(); ?></span>                    
				
				                    </a>
				
				                    <?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
				
				                </li>
				
				    <?php endwhile; ?>
				    <?php wp_reset_query(); ?>
    

					
					</ul>
					
					<ul>
					
										<?php
				        $args = array( 'post_type' => 'product', 'posts_per_page' => 4, 'product_cat' => $slid_cat_three, 'orderby' => 'rand' );
				        $loop = new WP_Query( $args );
				        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
				
				     
				                <li>    
				
				                    <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
				
				                        <?php woocommerce_show_product_sale_flash( $post, $product ); ?>
				
				                        <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
				
				                        <h4><?php the_title(); ?></h4>
				
				                        <span class="price"><?php echo $product->get_price_html(); ?></span>                    
				
				                    </a>
				
				                    <?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
				
				                </li>
				
				    <?php endwhile; ?>
				    <?php wp_reset_query(); ?>
    

					
					
					</ul>
					<ul>

										<?php
				        $args = array( 'post_type' => 'product', 'posts_per_page' => 4, 'product_cat' => $slid_cat_four, 'orderby' => 'rand' );
				        $loop = new WP_Query( $args );
				        while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
				
				     
				                <li>    
				
				                    <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
				
				                        <?php woocommerce_show_product_sale_flash( $post, $product ); ?>
				
				                        <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?>
				
				                        <h4><?php the_title(); ?></h4>
				
				                        <span class="price"><?php echo $product->get_price_html(); ?></span>                    
				
				                    </a>
				
				                    <?php woocommerce_template_loop_add_to_cart( $loop->post, $product ); ?>
				
				                </li>
				
				    <?php endwhile; ?>
				    <?php wp_reset_query(); ?>
    



					</ul>
					<nav>
						<a href="#"><?php echo $slid_cat_one; ?></a>
						<a href="#"><?php echo $slid_cat_two; ?></a>
						<a href="#"><?php echo $slid_cat_three; ?></a>
						<a href="#"><?php echo $slid_cat_four; ?></a>
					</nav>
				</div>
	
	</div>
	
	<?php } ?>
	<!-- end shop condition -->
<?php
		/**
		 * woocommerce_sidebar hook.
		 *
		 * @hooked woocommerce_get_sidebar - 10
		 */
		do_action( 'woocommerce_sidebar' );
	?>
	

	<?php
		/**
		 * woocommerce_before_main_content hook.
		 *
		 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
		 * @hooked woocommerce_breadcrumb - 20
		 */
		do_action( 'woocommerce_before_main_content' );
	?>

		
		
		<?php if ( have_posts() ) : ?>

			<?php
				/**
				 * woocommerce_before_shop_loop hook.
				 *
				 * @hooked woocommerce_result_count - 20
				 * @hooked woocommerce_catalog_ordering - 30
				 */
				do_action( 'woocommerce_before_shop_loop' );
			?>

			<?php woocommerce_product_loop_start(); ?>

				<?php woocommerce_product_subcategories(); ?>

				<?php while ( have_posts() ) : the_post(); ?>

					<?php wc_get_template_part( 'content', 'product' ); ?>

				<?php endwhile; // end of the loop. ?>

			<?php woocommerce_product_loop_end(); ?>

			<?php
				/**
				 * woocommerce_after_shop_loop hook.
				 *
				 * @hooked woocommerce_pagination - 10
				 */
				do_action( 'woocommerce_after_shop_loop' );
			?>

		<?php elseif ( ! woocommerce_product_subcategories( array( 'before' => woocommerce_product_loop_start( false ), 'after' => woocommerce_product_loop_end( false ) ) ) ) : ?>

			<?php wc_get_template( 'loop/no-products-found.php' ); ?>

		<?php endif; ?>

	<?php
		/**
		 * woocommerce_after_main_content hook.
		 *
		 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
		 */
		do_action( 'woocommerce_after_main_content' );
	?>

	

<?php get_footer( 'shop' ); ?>
