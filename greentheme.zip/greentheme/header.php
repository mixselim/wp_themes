<!DOCTYPE HTML>
<html <?php language_attributes(); ?> >
<head>
	<meta charset="UTF-8">
	<title><?php wp_title(); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/themes/default/default.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/themes/light/light.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/themes/dark/dark.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/themes/bar/bar.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/nivo-slider.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/html5reset.css" />
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/woocommerce.css" />
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/slicknav.css" />
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/slid.css" />
	
	<script src="https://use.fontawesome.com/51c0afbdf7.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/js/modernizr.custom.63321.js"></script>
	<?php  if ( is_singular() ) wp_enqueue_script( 'comment-reply' );
	
	 ?>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?> >
	
	<?php 
			$logo = get_option('logo');
			
		?>
		
	<div class="wrapper oh">
		<div class="header">
			<div class="head-up clr">
				<div class="logo fl">
					<img src="<?php echo $logo; ?>" alt="<?php bloginfo('name'); ?>" />
				</div>
				<div class="search fl">
					<?php get_product_search_form(); ?>
				</div>
				<div class="users fr">
					<ul>
					<?php if(!is_user_logged_in()){ ?>
					
						<li>
						<a href="<?php echo get_page_link(7); ?>"><i class="fa fa-sign-in color-font" aria-hidden="true"></i> login</a>		  
						</li>
						
						<?php } ?>
						
						<li>
						
						<span class=""><a class="cart-customlocation" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>">
						<i class="fa fa-cart-plus color-font" aria-hidden="true"></i>
						<?php 
						
						echo sprintf ( _n( '%d item', '%d items', WC()->cart->get_cart_contents_count() ), WC()->cart->get_cart_contents_count() ); ?> - <?php echo WC()->cart->get_cart_total();  ?></a>
</span>
						
						</li>
					</ul>
				</div>
			</div>
			<div class="navigation clr">
					<div class="menu-wrap">
						<nav class="menu">
						
						<?php	wp_nav_menu( array(
							    'theme_location' => 'primary-menu',
							    'container' => false,
							    
						
							) );
							
							?>
						
						</nav>
					</div>
					
					<!-- mobile menu -->
				
			</div>
			<div class="clr"></div>
		</div>
		
		