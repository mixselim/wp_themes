<aside class="sidebar">
	<div class="side-nav">
	
		<?php
		 
		$terms = get_terms( 'product_cat' );
		 
		if ( $terms ) {
		         
		    echo '<ul>';
		     
		        foreach ( $terms as $term ) {
		                         
		            echo '<li>';                 
		                     
		                 echo '<i class="fa fa-check fa-lg color-font" aria-hidden="true"></i>&nbsp;<a href="' .  esc_url( get_term_link( $term ) ) . '" class="' . $term->slug . '">';
		                        echo $term->name;
		                    echo '</a>';
		                                                                     
		            echo '</li>';
		                                                                     
		 
		    }
		     
		    echo '</ul>';
		 
		}
					
		
		?>
					
	</div>
	
	<?php dynamic_sidebar( 'main-sidebar' ); ?>
</aside>