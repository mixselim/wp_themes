<div style="clear:both;"></div>
		<div class="footer">
			<?php dynamic_sidebar( 'footer-text' ); ?>
		</div>
		<!-- end footer -->
	</div>
	
	
    <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.nivo.slider.js"></script>
    <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.slicknav.min.js"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/jquery.catslider.js"></script>
    <script type="text/javascript">
    jQuery(window).load(function() {
        jQuery('#slider').nivoSlider();
    });
    </script>
    
    <script>
    jQuery(document).ready(function() {
        jQuery('#menu-main-menu').addClass("clearfix").removeClass("menu");
	jQuery('#menu-main-menu li a ul').addClass("sub-menu");
        
    });
    </script>
    <script>
	jQuery(document).ready(function(){
		jQuery('.menu').slicknav({
			prependTo:'.navigation',
			label: ''
		});
	});
</script>
	<script>
			jQuery(document).ready(function() {

				jQuery( '#mi-slider' ).catslider();

			});
		</script>

    
	<?php wp_footer(); ?>
</body>
</html>