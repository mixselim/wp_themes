<?php
include_once('inc/breadcumbs.php');
include_once('inc/options.php');

add_theme_support( 'post-thumbnails', array( 'post', 'page' ) );
add_theme_support( 'title-tag' );
add_theme_support( 'automatic-feed-links' );


set_post_thumbnail_size( 480, 250, true );

if ( ! isset( $content_width ) ) $content_width = 900;


function greentheme_theme_scripts() {
 	wp_enqueue_style( 'style', get_stylesheet_uri() );
 	wp_enqueue_style( 'woo', get_template_directory_uri() . '/css/woo.css', array(), '1.1', 'all');
 	wp_enqueue_style( 'less', get_template_directory_uri() . '/css/less.css', array(), '1.0', 'all');
}
add_action( 'wp_enqueue_scripts', 'greentheme_theme_scripts' );

// Removes showing results

remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );


/* Menus */

function greentheme_register_primary_menu() {
  register_nav_menus(
				array(
      'primary-menu' => __( 'Primary Menu' ),
      'mobile-menu' => __( 'Mobile Menu' )
    ));
  }

add_action( 'after_setup_theme', 'greentheme_register_primary_menu' );



function greentheme_theme_name_scripts() {
    wp_enqueue_script( 'sdk', get_template_directory_uri() . '/js/appsdj.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'greentheme_theme_name_scripts' );



/* this is the hooks test */

function greentheme_theme_name_scripts_woo_hooks( $args = array() ){

	$parentid = get_queried_object_id();
	         
	$args = array(
	    'parent' => $parentid
	);
	 
	$terms = get_terms( 'product_cat', $args );
	 
	if ( $terms ) {
	         
	    echo '<ul class="product-cats">';
	     
	        foreach ( $terms as $term ) {
	                         
	            echo '<li class="category">';                 
	                     
	                woocommerce_subcategory_thumbnail( $term );
	                 
	                echo '<h2>';
	                    echo '<a href="' .  esc_url( get_term_link( $term ) ) . '" class="' . $term->slug . '">';
	                        echo $term->name;
	                    echo '</a>';
	                echo '</h2>';
	                                                                     
	            echo '</li>';
	                                                                     
	 
	    }
	     
	    echo '</ul>';
	 
	}

}

add_action( 'woocommerce_after_shop_loop', 'greentheme_theme_name_scripts_woo_hooks' );


/* edit */

remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

add_action('woocommerce_before_main_content', 'greentheme_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'greentheme_wrapper_end', 10);

function greentheme_wrapper_start() {
  echo '<section class="main-content"> <div class="content">';
}

function greentheme_wrapper_end() {
  echo '</div></section>';
}


add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

add_filter('add_to_cart_fragments', 'greentheme_header_add_to_cart_fragment');
 
function greentheme_header_add_to_cart_fragment( $fragments ) {
	global $woocommerce;
	
	ob_start();
	
	?>
	<a class="cart-customlocation" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'greentheme'); ?>"><?php echo sprintf(_n('%d item', '%d items', $woocommerce->cart->cart_contents_count, 'greentheme'), $woocommerce->cart->cart_contents_count);?> - <?php echo 
	$woocommerce->cart->get_cart_total(); ?></a>
	<?php
	
	$fragments['a.cart-customlocation'] = ob_get_clean();
	
	return $fragments;
	
}

/* comp */
/**
 * Add a sidebar.
*/
add_action( 'widgets_init', 'greentheme_slug_widgets_init' );

function greentheme_slug_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Main Sidebar', 'greentheme' ),
        'id'            => 'main-sidebar',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'greentheme' ),
        'before_widget' => '<div class="sidebar-content" >',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ) );
    
    register_sidebar( array(
        'name'          => __( 'Footer Text', 'greentheme' ),
        'id'            => 'footer-text',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'greentheme' ),
        'before_widget' => '',
        'after_widget'  => '',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ) );
}

/* theme admin panel */
function theme_settings_page(){
    ?>
	    <div class="wrap">
	    <h1>Theme Panel</h1>
	    <form method="post" action="options.php" enctype="multipart/form-data">
	        <?php
	            settings_fields("section");
	            do_settings_sections("theme-options");      
	            submit_button(); 
	        ?>          
	    </form>
		</div>
	<?php



}
function add_theme_menu_item()
{
	add_menu_page("Theme Panel", "Theme Panel", "manage_options", "theme-panel", "theme_settings_page", null, 99);
}

add_action("admin_menu", "add_theme_menu_item");
