<footer class="container">
        <div class="row Footer">
            <div class="row hidden-print" style="padding: 0;margin: 0;">
                <div class="col-sm-12 hidden-xs">
                    <div class="DFooter1Menu text-center">
                        <?php
						wp_nav_menu( array(
						  'theme_location' => 'footer-menu',
						  'container' => false,
						  'menu_class' => 'list-inline',
						  
						  ) );
						?>
						
						
                    </div>
                </div>
                <div class="col-sm-12 text-center hidden-xs" style="border-top: 2px solid #CC2223; padding: 10px;margin: 5px 0;font-size: 12px;">
                <?php dynamic_sidebar('footer-up'); ?>
				</div>
            </div>

            <div class="row" style="padding: 0;margin: 0;">
                <div class="col-sm-3 hidden-xs hidden-print" style="border-right: 3px solid #fff;">
                    <?php dynamic_sidebar('footer-one'); ?>
                </div>
                <div class="col-sm-4 text-center FooterInfo" style="border-right: 3px solid #fff;">
					<?php dynamic_sidebar('footer-two'); ?>
                </div>
                <div class="col-sm-5 text-center FooterInfo">
                <?php dynamic_sidebar('footer-three'); ?>
                </div>
            </div>
        </div>
        <div class="row" style="margin-bottom: 20px;">
            <div class="col-sm-12 bg-primary text-center">
                <?php dynamic_sidebar('footer-copy'); ?>
            </div>
        </div>
    </footer>
    <script>
        (function(i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function() {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o), m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
        ga('create', 'UA-11428839-44', 'auto');
        ga('send', 'pageview');
    </script>
	<a href="#0" class="cd-top">Top</a>
    <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/jquery.js"></script>
    
    
    <script src="<?php echo get_template_directory_uri(); ?>/js/analytics.js" async=""></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/gtm.js" async=""></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/sdk.js" id="facebook-jssdk"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/js/gpt.js" type="text/javascript" async=""></script>


    <script async="" src="<?php echo get_template_directory_uri(); ?>/pubads_impl_88.js"></script>
    
	<script>

	function test2(){
		var t_child = document.getElementById("nttl").value;
		window.location = t_child;
	}
	</script>
    
    
    <script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.js"></script>

	<script>
	function myFunction() {
		var e = document.getElementById("cboDivision");
		var select_val = e.options[e.selectedIndex].value;
		var ajaxUrl = "<?php echo admin_url('admin-ajax.php')?>";
		var data = {
			'action': 'jago_taxo_show',
			'terms_val': select_val      // We pass php values differently!
		};
		jQuery.post(ajaxUrl, data, function(response) {
			//alert('Got this from the server: ' + response);
			document.getElementById("nttl").innerHTML = '<option selected="selected" value="0">জেলা</option>';
			$("#nttl").append(response);
			
		});
		//alert("Hello! I am an alert box! "+ajaxUrl );
	}

	</script>


<script type="text/javascript">
	function fPrint(){
		window.print();
	}
</script>
	<?php wp_footer(); ?>
</body>

</html>