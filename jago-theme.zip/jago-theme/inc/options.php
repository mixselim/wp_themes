<?php

function modified( $argu ){
	?>
    	<select name="<?php echo $argu;?>" id="">
		<?php
				$categories = get_categories( array(
				'orderby' => 'name',
				'order'   => 'ASC'
			) );
			 
			foreach( $categories as $category ) {
				?>
				<option <?php if($category->name==get_option($argu)) echo 'selected'; ?> value="<?php echo $category->name; ?>"><?php echo $category->name; ?></option>
				<?php
			}
			?>
		</select>
    <?php
}

function logo_display()
{
	?>
        <input type="file" name="logo" id="logo" /> 
        <img src="<?php echo get_option('logo'); ?>" width="100" height="75" alt="" />
   <?php
}

function handle_logo_upload()
{
	if(!empty($_FILES["logo"]["tmp_name"]))
	{
		$urls = wp_handle_upload($_FILES["logo"], array('test_form' => FALSE));
	if ($urls["error"]) 
	{
		return $urls["error"];
	}
		$temp = $urls["url"];
		return $temp; 
	} 
	return get_option('logo');
}

function display_first_news(){			modified('first_news');			}
function display_tab1(){				modified('tab1');				}
function display_tab2(){				modified('tab2');				}
function display_first_row_last(){		modified('first_row_last');		}
function display_secound_row(){			modified('secound_row');		}
function display_third_row(){			modified('third_row');			}
function display_row_four_one(){		modified('row_four_one');		}
function display_row_four_two(){		modified('row_four_two');		}
function display_row_five_one(){		modified('row_five_one');		}
function display_row_five_two(){		modified('row_five_two');		}
function display_row_six_one(){			modified('row_six_one');		}
function display_row_six_two(){			modified('row_six_two');		}
function display_row_six_three(){ 		modified('row_six_three'); 		}
function display_row_seven(){			modified('row_seven'); 			}
function display_row_eight_one(){		modified('row_eight_one'); 		}
function display_row_eight_two(){		modified('row_eight_two'); 		}
function display_row_nine(){			modified('row_nine'); 			}
function display_row_ten_one(){			modified('row_ten_one'); 		}
function display_row_ten_two(){			modified('row_ten_two'); 		}
function display_row_ten_three(){		modified('row_ten_three'); 		}
function display_row_eleven_one(){		modified('row_eleven_one'); 	}
function display_row_eleven_two(){		modified('row_eleven_two'); 	}
function display_row_eleven_three(){	modified('row_eleven_three'); 	}
function display_row_towelve(){			modified('row_towelve'); }
function display_sidebar_tab_one(){		modified('sidebar_tab_one'); 	}
function display_sidebar_tab_two(){		modified('sidebar_tab_two'); 	}
function display_sidebar_tab_three(){	modified('sidebar_tab_three'); 	}
function display_sidebar_single_cat(){	modified('sidebar_single_cat'); }
 



function display_theme_panel_fields()
{
	//Settings Sections
	add_settings_section("section", "All Settings", null, "theme-options");
	
	//Settings Fields
	
	add_settings_field("logo", "Logo", "logo_display", "theme-options", "section");
    add_settings_field("first_news", "First News", "display_first_news", "theme-options", "section");
	add_settings_field("tab1", "Tab-1", "display_tab1", "theme-options", "section");
	add_settings_field("tab2", "Tab-2", "display_tab2", "theme-options", "section");
	add_settings_field("first_row_last", "First Row Last", "display_first_row_last", "theme-options", "section");
	add_settings_field("secound_row", "Secound Row", "display_secound_row", "theme-options", "section");
	add_settings_field("third_row", "Third Row", "display_third_row", "theme-options", "section");
	add_settings_field("row_four_one", "Row Four One", "display_row_four_one", "theme-options", "section");
	add_settings_field("row_four_two", "Row Four Two", "display_row_four_two", "theme-options", "section");
	add_settings_field("row_five_one", "Row Five One", "display_row_five_one", "theme-options", "section");
	add_settings_field("row_five_two", "Row Five Two", "display_row_five_two", "theme-options", "section");
	add_settings_field("row_six_one", "Row Six One", "display_row_six_one", "theme-options", "section");
	add_settings_field("row_six_two", "Row Six Two", "display_row_six_two", "theme-options", "section");
	add_settings_field("row_six_three", "Row Six Three", "display_row_six_three", "theme-options", "section");
	add_settings_field("row_seven", "Row Seven", "display_row_seven", "theme-options", "section");
	add_settings_field("row_eight_one", "Row Eight One", "display_row_eight_one", "theme-options", "section");
	add_settings_field("row_eight_two", "Row Eight Two", "display_row_eight_two", "theme-options", "section");
	add_settings_field("row_nine", "Row Nine", "display_row_nine", "theme-options", "section");
	add_settings_field("row_ten_one", "Row Ten One", "display_row_ten_one", "theme-options", "section");
	add_settings_field("row_ten_two", "Row Ten Two", "display_row_ten_two", "theme-options", "section");
	add_settings_field("row_ten_three", "Row Ten Three", "display_row_ten_three", "theme-options", "section");
	add_settings_field("row_eleven_one", "Row Eleven One", "display_row_eleven_one", "theme-options", "section");
	add_settings_field("row_eleven_two", "Row Eleven Two", "display_row_eleven_two", "theme-options", "section");
	add_settings_field("row_eleven_three", "Row Eleven Three", "display_row_eleven_three", "theme-options", "section");
	add_settings_field("row_towelve", "Row Towelve", "display_row_towelve", "theme-options", "section");
	add_settings_field("sidebar_tab_one", "Sidebar Tab One", "display_sidebar_tab_one", "theme-options", "section");
	add_settings_field("sidebar_tab_two", "Sidebar Tab Two", "display_sidebar_tab_Two", "theme-options", "section");
	add_settings_field("sidebar_tab_three", "Sidebar Tab Three", "display_sidebar_tab_three", "theme-options", "section");
	add_settings_field("sidebar_single_cat", "Sidebar Single Cat", "display_sidebar_single_cat", "theme-options", "section");
	
	
	
	//Register Settings
    register_setting("section", "logo", "handle_logo_upload");
	register_setting("section", "first_news");
    register_setting("section", "tab1");
    register_setting("section", "tab2");
    register_setting("section", "first_row_last");
    register_setting("section", "secound_row");
    register_setting("section", "third_row");
    register_setting("section", "row_four_one");
    register_setting("section", "row_four_two");
    register_setting("section", "row_five_one");
    register_setting("section", "row_five_two");
    register_setting("section", "row_six_one");
    register_setting("section", "row_six_two");
    register_setting("section", "row_six_three");
    register_setting("section", "row_seven");
    register_setting("section", "row_eight_one");
    register_setting("section", "row_eight_two");
    register_setting("section", "row_nine");
    register_setting("section", "row_ten_one");
    register_setting("section", "row_ten_two");
    register_setting("section", "row_ten_three");
    register_setting("section", "row_eleven_one");
    register_setting("section", "row_eleven_two");
    register_setting("section", "row_eleven_three");
    register_setting("section", "row_towelve");
    register_setting("section", "sidebar_tab_one");
    register_setting("section", "sidebar_tab_two");
    register_setting("section", "sidebar_tab_three");
    register_setting("section", "sidebar_single_cat");
	
}

add_action("admin_init", "display_theme_panel_fields");

?>