<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php bloginfo('description'); ?> | <?php bloginfo('name'); ?> </title>
    <meta name="description" content="<?php bloginfo('name'); ?> , the fastest growing news portal has been providing all bangla news, breaking news and other related Bangladesh news since 2014.">
    <meta name="news_keywords" content="Bangla news, Bangladesh News, all bangla news, bd news, bangla news 24, বা্লা নিউজ, বাংলা বিডি নিউজ ,বাংলা নিউজ পেপার ,বাংলা নিউজ ২৪,বাংলা নিউজ ,বাংলা নিউজ, news from bangladesh, latest news of bangladesh, breaking news of bangladesh, todays news of bangladesh, today bangla news, online bangla news, everyday bangla news">
    <meta name="author" content="SELIM AHMAD">
    <meta name="robots" content="all">
    <link rel="canonical" href="">
    <meta http-equiv="cache-control" content="no-cache">
    <meta http-equiv="pragma" content="no-cache">
    <meta name="p:domain_verify" content="">
    <meta property="fb:pages" content="">
    <meta name="alexaVerifyID" content="">
    <link rel="shortcut icon" type="image/x-icon" href="">
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_uri(); ?>">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
    

	<?php wp_head(); ?>
</head>

<body id="top">
    <div class=" fb_reset" id="fb-root">
    </div>
    <script>
        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s);
            js.id = id;
            js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.3&appId=1389850874590112";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
    </script>
    <!-- Google Tag Manager -->
    <noscript>
        <iframe src="//www.googletagmanager.com/ns.html?id=GTM-PJ4VJP" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                '//www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-PJ4VJP');
    </script>
    <!-- End Google Tag Manager -->
    <div class="visible-print-inline-block HeaderPrint text-center">
        <img src="<?php echo get_template_directory_uri(); ?>/Jago-News-logo.jpg" alt="Jago News logo" title="Jago News logo">
    </div>
    <header class="container hidden-print">
        
        <div class="row">
            <div class="col-sm-12 border-top-red">
                <div class="row text-center">
                    <div class="pull-left" id="HeaderDateTime"><?php echo date('l jS F Y'); ?>
 </div>
                    <div class="pull-right hidden-xs" id="HeaderIconSearch">
                        <a href="#" target="_blank">
                            
                        </a>
                        <a href="#" target="_blank" rel="nofollow"><i class="fa fa-facebook"></i></a>
                        <a href="#" target="_blank" rel="nofollow"><i class="fa fa-twitter"></i></a>
                        <a href="#" target="_blank" rel="nofollow"><i class="fa fa-google-plus"></i></a>
                        <a href="#" target="_blank" rel="nofollow"><i class="fa fa-youtube"></i></a>
                        <a href="#" target="_blank" rel="nofollow"><i class="fa fa-android" style="color: #A5d11c;"></i></a>
                        <a href="#" target="_blank" rel="nofollow"><i class="fa fa-windows" style="color: #00ade5;"></i></a>
                        <a href="#" target="_blank" rel="nofollow"><i class="fa fa-apple" style="color: #999;"></i></a>
                        <a href="#" target="_blank" rel="nofollow"><i class="fa fa-rss"></i></a>

                        <form method="get" class="navbar-form navbar-right searchform group" role="search" action="<?php echo home_url( '/' ); ?>" id="HeaderSearch">
                            <div class="form-group hidden-xs">
                                <input value="<?php echo get_search_query() ?>" name="s" id="q" class="form-control input-sm bg-aches" placeholder="<?php echo esc_attr_x( 'Search', 'placeholder' ) ?>" type="search" >
                            </div>
                            <button type="submit" class="btn btn-default btn-sm bg-aches hidden-xs" id="sa" value="" ><i class="fa fa-search"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 col-sm-12 headSection">
                <div class="visible-xs text-center">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <img src="<?php echo get_option('logo'); ?>" alt="<?php bloginfo( 'name' ); ?>" title="<?php bloginfo( 'name' ); ?>" id="HeaderLogo">
                    </a>
                </div>
                <div class="pull-left hidden-xs">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo get_option('logo'); ?>" class="img-responsive" alt="<?php bloginfo( 'name' ); ?>" title="<?php bloginfo( 'name' ); ?>" id="HeaderLogo">
                    </a>
                </div>
                <div class="pull-right hidden-xs"> 
                    <a href="#" rel="nofollow" target="_blank">
					<?php dynamic_sidebar('adds-top'); ?>
					</a>
                </div>
            </div>
        </div>
        <div class="row" id="nav">
            <nav class="navbar navbar-default" role="navigation">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<?php /* Primary navigation */
						wp_nav_menu( array(
						  'theme_location' => 'primary-menu',
						  'depth' => 2,
						  'container' => false,
						  'menu_class' => 'nav navbar-nav',
						  //Process nav menu using our custom nav walker
						  'walker' => new wp_bootstrap_navwalker())
						);
						?>
					
					
<!--					<ul class="nav navbar-nav">
                        <li><a href="">প্রচ্ছদ</a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle disabled" data-toggle="dropdown">বাংলাদেশ <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="">জাতীয়</a>
                                </li>
                                <li><a href="">রাজনীতি</a>
                                </li>
                                <li><a href="">অর্থনীতি</a>
                                </li>
                            </ul>
                        </li>
                        <li><a href="">আন্তর্জাতিক</a>
                        </li>
                        <li class="dropdown">
                            <a href="" class="dropdown-toggle disabled" data-toggle="dropdown">দেশজুড়ে  <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="">জেলার খবর</a>
                                </li>
                            </ul>
                        </li>
                        <li><a href="">খেলাধুলা</a>
                        </li>
                        <li><a href="">বিনোদন</a>
                        </li>
                        <li><a href="">লাইফস্টাইল</a>
                        </li>
                        <li><a href="">মতামত</a>
                        </li>
                        <li><a href="">জবস</a>
                        </li>
                        <li><a href="">সাহিত্য</a>
                        </li>
                        <li><a href="" target="_blank">ফটো গ্যালারি</a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">অন্যান্য <b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li><a href="">ধর্ম</a>
                                </li>
                                <li><a href="">স্বাস্থ্য</a>
                                </li>
                                <li><a href="">প্রবাস</a>
                                </li>
                                <li><a href="">শিক্ষা</a>
                                </li>
                                <li><a href="">ক্যাম্পাস</a>
                                </li>
                                <li><a href="">জোকস</a>
                                </li>
                                <li><a href="">তথ্যপ্রযুক্তি</a>
                                </li>
                                <li><a href="">গণমাধ্যম</a>
                                </li>
                                <li><a href="">আইন-আদালত</a>
                                </li>
                                <li><a href="">আজকের আয়োজন</a>
                                </li>
                                <li class="divider"></li>
                                <li><a href="" rel="nofollow">অ্যাপস</a>
                                </li>
                                <li><a href="">আর্কাইভ</a>
                                </li>
                                <li><a href="">স্যোশাল মিডিয়া</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
					-->
                </div>
            </nav>
        </div>
		
		<script>
		jQuery( document ).ready(function() {
			jQuery( ".nav li ul" ).addClass( "dropdown-menu" );
		}
		</script>
				
    </header>