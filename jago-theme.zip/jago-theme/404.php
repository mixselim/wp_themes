<?php get_header(); ?>
    <section class="container">
        <div class="row margin-top-10px">
            
                <article class="col-sm-8 DetailsContent" style="padding-left: 0;">
					<h2>404 Not Found!</h2>

				</article>
				
				<?php get_template_part('sidebar'); ?>
				
        </div>
    </section>
    <div class="container">
        <div class="row">
            <a href="#" rel="nofollow" target="_blank">
                <?php dynamic_sidebar('adds-footer'); ?>
            </a>
        </div>
    </div>
   <?php get_footer(); ?>