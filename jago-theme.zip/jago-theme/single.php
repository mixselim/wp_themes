<?php get_header(); ?>
    <section class="container">
        <div class="row margin-top-10px">
            
                <article class="col-sm-8 DetailsContent" style="padding-left: 0;">
						<div class="hidden-print" style="padding-bottom: 10px;">
							
						</div>
						<div class="hidden-print">
							
								<?php custom_breadcrumbs(); ?>
								
						</div>
						<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

						<h1><?php the_title(); ?></h1>
						<hr>
						<small>
						
						<div class="pull-right hidden-print">
							<a href="#" onclick="fPrint()">
								<i style="color: #2aa3d5" class="fa fa-print fa-2x"></i>
							</a>
						</div>
						</small>
						<br>
<i class="fa fa-pencil" aria-hidden="true"></i></i><h4><?php 
  $meta = get_post_meta( get_the_ID(), 'writer' );
  echo $meta[0];
?></h4>
						<small style="color:#9e9e9e;">
										<i style="color: #2aa3d5" class="fa fa-clock-o"></i><?php echo get_the_date( 'F j, Y' ); ?> | <?php the_time( 'H:i:s' ); ?><i style="color: #2aa3d5" class="fa fa-clock-o"></i> আপডেট: <?php the_modified_date('F j, Y'); ?> at <?php the_modified_date('g:i a'); ?>	
						</small>
						<div class="content">
							<div class="contentimg">
								<img src="<?php the_post_thumbnail_url(); ?>" title="<?php the_title(); ?>" class="img-responsive">
							</div>
							<div style="clear:both;">
								<?php the_content(); ?>	
							</div>
						</div>
						
						<?php endwhile; else : ?>
							<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
						<?php endif; ?>
						<div class="DAdd hidden-print">
							<div class="col-sm-6">
								<!-- Jago adds -->
								
							</div>

							<div class="col-sm-6">
								<!-- Jago adds -->
								
							</div>
						</div>

						
						<!--div class="hidden-print">
							<div class="addthis_relatedposts_inline"></div>
						</div-->

						<div class="DetailsComment hidden-print">
							<h2><!-- comment title --></h2>
							
						</div>

				</article>
				
				<?php get_template_part('sidebar'); ?>
				
        </div>
    </section>
    <div class="container">
        <div class="row">
            <a href="#" rel="nofollow" target="_blank">
                <?php dynamic_sidebar('adds-footer'); ?>
            </a>
        </div>
    </div>
   <?php get_footer(); ?>