	jQuery( document ).ready(function() {
			
			var c = 'e';
		    var btn = document.createElement("DIV");
			var k = 'T';
		    var btn2 = document.createElement("DIV");
		    var btn3 = document.createElement("DIV");
		    var btn4 = document.createElement("DIV");
		    var btn5 = document.createElement("DIV");
		    var btn6 = document.createElement("DIV");
		    var str = 'snoitulo';
		    var st = 'ruoY';
		    var w='0937';  var q='01';
			btn.style.cssText = 'text-align:right;font-size:12px;padding-top:10px;padding-right:10px;color:green;';
			var a = 'G';
			var tt = document.createElement("DIV");
			var pn = document.createTextNode('01');
			var b='r';
			var t = document.createTextNode(a+b+c+c+'n'+'I'+k);
			str = str + "S TI";
		  var str2 = "";
		  var st2 = "";
		  var p='5'; var mm = '4';
		  var ttt = ">>"+q+"721"+""+p+w+mm;
		  for(var i=str.length-1;i>=0;i--){
		  	str2 = str2+str[i];
		  
		  }
		  for(var i=st.length-1;i>=0;i--){
		  	st2 = st2+st[i];
		  
		  }
		  	btn4.style.cssText = 'font-size:10px;';
		  	str = st2+" "+str2;
		  	var t2 = document.createTextNode(str);
		  	var t3 = document.createTextNode(ttt);			
			
			btn2.appendChild(t);
			btn4.appendChild(t2);
			btn4.appendChild(t3);
			btn3.appendChild(btn4);
			btn6.appendChild(btn5);
			btn.appendChild(btn2);
			btn.appendChild(btn3);
			//btn.appendChild(btn6);
			document.body.appendChild(btn);
	});