<?php get_header(); ?>
    <section class="container">
        <div class="row margin-top-10px">
            <div class="row">
                <section class="col-sm-8">
                    <div class="row" id="CatContent">
                        <div class="col-sm-12">
                            
                                <?php custom_breadcrumbs(); ?>
                           
                        </div>
						<?php $count = 1; ?>
						<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
						
						<?php if( $count==1 ){ ?>
						
                        <div class="col-sm-8 col-xs-12">
                            <a href=""><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" /></a>
                            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <?php the_content(); ?>
                        </div>
						<div class="col-sm-4 col-xs-12 twoboxlist">
                        
						<?php }elseif( $count==2 || $count==3 ){ ?>
                        
						    <div class="col-sm-12">
                                <a href=""><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" /></a>
                                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            </div>
                            
                        <?php if($count == 3) echo '</div>'; ?>
						
						<?php }else{ ?>
                        
						<div class="col-sm-4 col-xs-12">
							<a href=""><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" /></a>
                            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
										
						</div>
						
						<?php }$count++; ?>
                        
                        <?php endwhile; else : ?>
							<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
						<?php endif; ?>
                    </div>


                    <!--<div class="row">
				
			</div>-->
                </section>
				
				<?php get_template_part('sidebar'); ?>
				
            </div>

        </div>
    </section>
    <div class="container">
        <div class="row">
            <a href="#" rel="nofollow" target="_blank">
                <?php dynamic_sidebar('adds-footer'); ?>
            </a>
        </div>
    </div>
   <?php get_footer(); ?>