<?php 
	$cat25 = get_option('sidebar_tab_one');
	$cat26 = get_option('sidebar_tab_two');
	$cat27 = get_option('sidebar_tab_three');
	$cat28 = get_option('sidebar_single_cat');

?>
                <aside class="col-sm-4 col-xs-12">
                    <div class="row" style="overflow: hidden; margin-bottom: 10px;">
                        <div class="col-sm-12">
                            <?php dynamic_sidebar('sidebar'); ?>
                        </div>
                    </div>

                    <div class="clearfix"></div>
                    <div class="DetailsNewsList">
                        <div class="row" id="LatestNewsList">
                            <ul class="nav nav-tabs">
                                <li class="active"><a data-toggle="tab" href="#Sports"><?php echo $cat25; ?></a>
                                </li>
                                <li><a data-toggle="tab" href="#Entertenment"><?php echo $cat26; ?></a>
                                </li>
                                <li><a data-toggle="tab" href="#LifeStyle"><?php echo $cat27; ?></a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div id="Sports" class="tab-pane fade in active">
                                    <ul class="list-group">
										<?php 
											// the query
											$the_query1 = new WP_Query( array(
														'category_name' => $cat25,
														'post_type'     => 'post',
														'posts_per_page' => '3'

														) ); ?>

											<?php if ( $the_query1->have_posts() ) : ?>

												<!-- pagination here -->

												<!-- the loop -->
										
												<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
							<li class="list-group-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
												<?php endwhile; ?>
												<!-- end of the loop -->

												<!-- pagination here -->

												<?php wp_reset_postdata(); ?>

											<?php else : ?>
												<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
											<?php endif; ?>
											
									
                                    </ul>
                                </div>
                                <div id="Entertenment" class="tab-pane fade">
                                    <ul class="list-group">
                                        <?php 
											// the query
											$the_query1 = new WP_Query( array(
														'category_name' => $cat26,
														'post_type'     => 'post',
														'posts_per_page' => '3'

														) ); ?>

											<?php if ( $the_query1->have_posts() ) : ?>

												<!-- pagination here -->

												<!-- the loop -->
										
												<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
							<li class="list-group-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
												<?php endwhile; ?>
												<!-- end of the loop -->

												<!-- pagination here -->

												<?php wp_reset_postdata(); ?>

											<?php else : ?>
												<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
											<?php endif; ?>
											
                                    </ul>
                                </div>
                                <div id="LifeStyle" class="tab-pane fade">
                                    <ul class="list-group">
                                        <?php 
											// the query
											$the_query1 = new WP_Query( array(
														'category_name' => $cat27,
														'post_type'     => 'post',
														'posts_per_page' => '3'

														) ); ?>

											<?php if ( $the_query1->have_posts() ) : ?>

												<!-- pagination here -->

												<!-- the loop -->
										
												<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
							<li class="list-group-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
												<?php endwhile; ?>
												<!-- end of the loop -->

												<!-- pagination here -->

												<?php wp_reset_postdata(); ?>

											<?php else : ?>
												<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
											<?php endif; ?>
											
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel panel-primary" id="ElectedNews">
                        <div class="panel-heading text-center"><?php echo $cat28; ?></div>
                        <?php 
											// the query
											$the_query1 = new WP_Query( array(
														'category_name' => $cat28,
														'post_type'     => 'post',
														'posts_per_page' => '3'

														) ); ?>

											<?php if ( $the_query1->have_posts() ) : ?>

												<!-- pagination here -->

												<!-- the loop -->
										
												<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
							<div class="media">
                            <div class="media-left">
                                <a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                            </div>
                        </div>
												<?php endwhile; ?>
												<!-- end of the loop -->

												<!-- pagination here -->

												<?php wp_reset_postdata(); ?>

											<?php else : ?>
												<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
											<?php endif; ?>
											
						
                        <div style="margin: 5px 0;text-align: right;">
                            <a href="<?php echo get_category_link(get_cat_ID($cat28)); ?>"><button class="btn btn-sm btn-primary" type="submit"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</button></a>
                            
                        </div>
                    </div>

                    <div class="DetailsNewsList">
                        <div class="row" id="LatestNewsList">
                            <ul class="nav nav-tabs">
                                <li class="active"><a data-toggle="tab" href="#home">সর্বশেষ</a>
                                </li>
                                <li><a data-toggle="tab" href="#menu1">জনপ্রিয়</a>
                                </li>
                                <li><a data-toggle="tab" href="#menu2">আলোচিত</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div id="home" class="tab-pane fade in active">
                                    <div class="panel panel-primary dLimit latestBox">
                                 <?php 
											// the query
											$the_query1 = new WP_Query( array(
														
														'post_type'     => 'post',
														'posts_per_page' => '3'

														) ); ?>

											<?php if ( $the_query1->have_posts() ) : ?>

												<!-- pagination here -->

												<!-- the loop -->
										
												<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
							<div class="media">
                                            <div class="media-left">
                                                <a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" >
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <h4 class="media-heading">
					<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
				</h4>
                                            </div>
                                        </div>
												<?php endwhile; ?>
												<!-- end of the loop -->

												<!-- pagination here -->

												<?php wp_reset_postdata(); ?>

											<?php else : ?>
												<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
											<?php endif; ?>
										
                                    </div>
                                </div>
                                <div id="menu1" class="tab-pane fade">
                                    <div class="panel panel-primary dLimit latestBox">
                                        
										
										  <?php 
											// the query
											$the_query1 = new WP_Query( array(
														
														'post_type'     => 'post',
														'posts_per_page' => '3',
														'meta_key' => 'wpb_post_views_count',
														'orderby' => 'meta_value_num',
														'order' => 'DESC'
														) ); ?>

											<?php if ( $the_query1->have_posts() ) : ?>

												<!-- pagination here -->

												<!-- the loop -->
										
												<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
							<div class="media">
                                            <div class="media-left">
                                                <a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" >
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <h4 class="media-heading">
					<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
				</h4>
                                            </div>
                                        </div>
												<?php endwhile; ?>
												<!-- end of the loop -->

												<!-- pagination here -->

												<?php wp_reset_postdata(); ?>

											<?php else : ?>
												<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
											<?php endif; ?>
									
                                    </div>
                                </div>
                                <div id="menu2" class="tab-pane fade">
                                    <div class="panel panel-primary dLimit latestBox">
                                        
										
										  <?php 
											// the query
											$the_query1 = new WP_Query( array(
														
														'post_type'     => 'post',
														'posts_per_page' => '3',
														'orderby' => 'comment_count',
														'order' => 'DESC'
														) ); ?>

											<?php if ( $the_query1->have_posts() ) : ?>

												<!-- pagination here -->

												<!-- the loop -->
										
												<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
							<div class="media">
                                            <div class="media-left">
                                                <a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" >
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <h4 class="media-heading">
					<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
				</h4>
                                            </div>
                                        </div>
												<?php endwhile; ?>
												<!-- end of the loop -->

												<!-- pagination here -->

												<?php wp_reset_postdata(); ?>

											<?php else : ?>
												<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
											<?php endif; ?>
										
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </aside>