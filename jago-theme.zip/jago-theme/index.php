<?php get_header(); ?>
    
	<?php 
		$cat1 = get_option('first_news');
		$cat2 = get_option('tab1');
		$cat3 = get_option('tab2');
		$cat4 = get_option('first_row_last');
		$cat5 = get_option('secound_row');
		$cat6 = get_option('third_row');
		$cat7 = get_option('row_four_one');
		$cat8 = get_option('row_four_two');
		$cat9 = get_option('row_five_one');
		$cat10 = get_option('row_five_two');
		$cat11 = get_option('row_six_one');
		$cat12 = get_option('row_six_two');
		$cat13 = get_option('row_six_three');
		$cat14 = get_option('row_seven');
		$cat15 = get_option('row_eight_one');
		$cat16 = get_option('row_eight_two');
		$cat17 = get_option('row_nine');
		$cat18 = get_option('row_ten_one');
		$cat19 = get_option('row_ten_two');
		$cat20 = get_option('row_ten_three');
		$cat21 = get_option('row_eleven_one');
		$cat22 = get_option('row_eleven_two');
		$cat23 = get_option('row_eleven_three');
		$cat24 = get_option('row_towelve');
	
	?>
	<section class="container">
        <div class="row" id="LeadNews">
            <div class="col-sm-5 col-xs-12" id="LeadNewsBox">
			<?php 
			// the query
			
			$the_query = new WP_Query( array(
						'category_name' => $cat1,
						'post_type'     => 'post',
						'posts_per_page' => '1'

						) ); ?>

			<?php if ( $the_query->have_posts() ) : ?>

				<!-- pagination here -->

				<!-- the loop -->
				<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
					
				<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" /></a>
				<div>
                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<?php echo content(30); ?>
				</div>	
					
				<?php endwhile; ?>
				<!-- end of the loop -->

				<!-- pagination here -->

				<?php wp_reset_postdata(); ?>

			<?php else : ?>
				<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
			<?php endif; ?>
			
				
                
            </div>
            <div class="col-sm-3 col-xs-12">
                <div id="LatestNewsListNew">
				
                    <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#home"><?php echo $cat2; ?></a>
                        </li>
                        <li><a data-toggle="tab" href="#menu1"><?php echo $cat3; ?></a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div id="home" class="tab-pane fade in active">
                            <div class="panel panel-primary dLimit latestBox">
                                <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat2,
											'post_type'     => 'post',
											'posts_per_page' => '8'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
										<div class="media">
											<div class="media-left">
												<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>"  ></a>
											</div>
											<div class="media-body">
												<h4 class="media-heading">
													<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
												</h4>
											</div>
										</div>	
										
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
								
													
								
								
                     
                            </div>
                        </div>
                        <div id="menu1" class="tab-pane fade">
                            <div class="panel panel-primary dLimit latestBox">
                                  <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat3,
											'post_type'     => 'post',
											'posts_per_page' => '4'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
										<div class="media">
											<div class="media-left">
												<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" ></a>
											</div>
											<div class="media-body">
												<h4 class="media-heading">
													<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
												</h4>
											</div>
										</div>	
										
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
			
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="col-sm-4 hidden-xs" id="Opinion">
                <div class="panel panel-primary">
                    <div class="panel-heading text-center"><a href="<?php echo get_category_link(get_cat_ID($cat4)); ?>"><?php echo $cat4; ?></a>
                    </div>
					  <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat4,
											'post_type'     => 'post',
											'posts_per_page' => '2'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
										<div class="media">
											<div class="media-left">
												<a href="<?php the_permalink(); ?>">
				<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" ></a>
											</div>
											<div class="media-body">
												<h4 class="media-heading">
													<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
												</h4>
											</div>
										</div>	
										
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
								
               
                    <a href="#" rel="nofollow" target="_blank">
                        
                    </a><!-- ads -->
                </div>
            </div>
        </div>

        <div class="row" id="SpecialLeatest" style="padding-top: 10px;">
            <div class="col-sm-8 col-xs-12" id="SpecialBox">
                <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat5,
											'post_type'     => 'post',
											'posts_per_page' => '9'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
										<div class="col-sm-4 col-xs-12">
											<a href="<?php the_permalink(); ?>">
											<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" /></a>
											
											<h2><a href="<?php the_permalink(); ?>">
											<?php the_title(); ?></a></h2>
										</div>
										
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
            </div>

            <div class="col-sm-4 col-xs-12">
                <?php dynamic_sidebar('sidebar'); ?>
                
            </div>
        </div>

        <!--<div class="row" id="Exclusive">
			</div>-->
        <div class="row" id="ExclusiveNew">
			<?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat6,
											'post_type'     => 'post',
											'posts_per_page' => '4'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
										<div class="col-sm-3">
											<a href="<?php the_permalink(); ?>">
											<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" >
											</a><a href="<?php the_permalink(); ?>"><h4><?php the_title(); ?></h4></a>
										</div>
										
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
							
        </div>
		<!-- horizontal news -->
        <div class="row DAdd">
            <div class="col-sm-6">
                <a href="#" rel="nofollow" target="_blank">
                <?php dynamic_sidebar('adds-middle2-left'); ?>
				</a>
            </div>
            <div class="col-sm-6">
                <a href="#" rel="nofollow" target="_blank">
                <?php dynamic_sidebar('adds-middle2-right'); ?>
				</a>
            </div>
        </div>

        <div class="row">
		<?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat7,
											'post_type'     => 'post',
											'posts_per_page' => '10'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
										<?php if( $count == 0 ){ ?>
										<div class="col-sm-4">
											<div class="row CatLeadBox">
												<div class="panel panel-primary visible-xs" style="margin-top: 10px;">
													<div class="panel-heading"><a href="<?php echo get_category_link(get_cat_ID($cat7)); ?>"><?php echo $cat7; ?></a>
													</div>
												</div>
												<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" ></a>
												<h2><a href=""><?php the_title(); ?></a></h2>
												<?php echo content(30); ?>
											</div>
										</div>
										<div class="col-sm-4 CatBox">
											<div class="panel panel-primary">
												<div class="panel-heading hidden-xs"><a href="<?php echo get_category_link(get_cat_ID($cat7)); ?>"> <?php echo $cat7; ?></a>
												</div>
												<ul class="list-group">
										<?php }else { ?>
					<li class="list-group-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </li>
										<?php }  $count++; ?>
									<?php endwhile; ?>
									 </ul>
									<div class="pull-right">
									<a href="<?php echo get_category_link(get_cat_ID($cat7)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
									</div>
								</div>
							</div>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
							
	
            <div class="col-sm-4 col-xs-12">
                <div class="row CatBoxList">
                    <div class="panel panel-primary">
                        <div class="panel-heading"><a href="<?php echo get_category_link(get_cat_ID($cat8)); ?>"><?php echo $cat8; ?></a>
                        </div>
						<?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat8,
											'post_type'     => 'post',
											'posts_per_page' => '4'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
										<div class="media">
											<div class="media-left">
												<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" ></a>
											</div>

											<div class="media-body">
												<h4 class="media-heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
											</div>
										</div>
										
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
							
                      
                        <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat8)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
		<div class="row DAdd">
            <div class="col-sm-6">
                <a href="#" rel="nofollow" target="_blank">
                <?php dynamic_sidebar('adds-middle1-left'); ?>
				</a>
            </div>
            <div class="col-sm-6">
                <a href="#" rel="nofollow" target="_blank">
                <?php dynamic_sidebar('adds-middle1-right'); ?>
				</a>
            </div>
        </div>

        <div class="row" style="margin-top: 10px;">
            <div class="row">
                <div class="col-sm-8" id="Sports">
					<?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat9,
											'post_type'     => 'post',
											'posts_per_page' => '6'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
										<?php if( $count==0 ){?>
											<div class="col-sm-12">
												<div class="row SportsCatBox">
													<div class="panel panel-primary">
														<div class="panel-heading">
															<i class="fa fa-bars"></i>
															<a href=""><?php echo $cat9; ?></a>
														</div>
														<div class="panel-body">
															<div class="media" style="padding: 10px 0 0 0;">
																<div class="media-left" style="width: 50%;">
																	<a href="<?php the_permalink(); ?>">
																	<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" >
																	</a>
																</div>

																<div class="media-body">
																	<h4 class="media-heading">
																		<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
																	<div class="hidden-xs">
																		<?php  echo content(30); ?>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>

											<div class="col-sm-6">
												<div class="row">
										<?php }elseif( $count==1 ){ ?>
											<div class="media" style="padding: 10px 0;">
												<div class="media-left" style="width: 50%;">
													<a href="<?php the_permalink(); ?>">
													<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" >
													</a>
												</div>
												<div class="media-body">
													<h4 class="media-heading">
													<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
													</h4>
												</div>
											</div>
										<?php }elseif( $count==2 ) { ?>
											<div class="media" style="padding: 10px 0;">
												<div class="media-left" style="width: 50%;">
													<a href="<?php the_permalink(); ?>">
													<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" >
													</a>
												</div>
												<div class="media-body">
													<h4 class="media-heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
												</div>
											</div>
										</div>
									</div>

									<div class="col-sm-6">
										<div class="row SportsCatList">
											<ul class="list-group">
										<?php }else{ ?>
										
										<li class="list-group-item"><a href="<?php the_title(); ?>"><?php the_title(); ?></a></li>
										
										<?php } $count++; ?>
										
										
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
							
                            </ul>
                            <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat9)); ?>" style="color: darkgreen;"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 CatSingleBox" style="padding-left: 5px;">
                    <div class="panel panel-primary">
                        <div class="panel-heading cat-ash"><a href="<?php echo get_category_link(get_cat_ID($cat10)); ?>"><?php echo $cat10;?></a>
                        </div>
						<?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat10,
											'post_type'     => 'post',
											'posts_per_page' => '4'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
										<?php if( $count == 0 ){ ?>
											<div class="panel-body">
												<a href="<?php the_permalink(); ?>">
												<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" >
												</a>
											</div>

											<ul class="list-group">
											<li class="list-group-item"><a href="<?php the_title(); ?>"><?php the_title(); ?></a>
                            </li>			
										<?php }else{ ?>
							<li class="list-group-item"><a href="<?php the_title(); ?>"><?php the_title(); ?></a>
                            </li>			
										
										<?php }  $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
							
                        </ul>
                        <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat10)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row margin-top-10px">
            <div class="row">
                <div class="col-sm-4 CatSingleBox">
                    <div class="panel panel-primary">
                        <div class="panel-heading cat-ash"><a href="<?php echo get_category_link(get_cat_ID($cat11)); ?>"><?php echo $cat11; ?></a>
                        </div>
                        <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat11,
											'post_type'     => 'post',
											'posts_per_page' => '4'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
										<?php if( $count == 0 ){ ?>
											<div class="panel-body">
												<a href="<?php the_permalink(); ?>">
												<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" >
												</a>
											</div>

											<ul class="list-group">
											<li class="list-group-item"><a href="<?php the_title(); ?>"><?php the_title(); ?></a>
                            </li>			
										<?php }else{ ?>
							<li class="list-group-item"><a href="<?php the_title(); ?>"><?php the_title(); ?></a>
                            </li>			
										
										<?php }  $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
                        </ul>
                        <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat11)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 CatSingleBox">
                    <div class="panel panel-primary">
                        <div class="panel-heading cat-blue"><a href="<?php echo get_category_link(get_cat_ID($cat12)); ?>"><?php echo $cat12;?></a>
                        </div>
                        <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat12,
											'post_type'     => 'post',
											'posts_per_page' => '4'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
										<?php if( $count == 0 ){ ?>
											<div class="panel-body">
												<a href="<?php the_permalink(); ?>">
												<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" >
												</a>
											</div>

											<ul class="list-group">
											<li class="list-group-item"><a href="<?php the_title(); ?>"><?php the_title(); ?></a>
                            </li>			
										<?php }else{ ?>
							<li class="list-group-item"><a href="<?php the_title(); ?>"><?php the_title(); ?></a>
                            </li>			
										
										<?php }  $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
                        </ul>
                        <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat12)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 CatSingleBox">
                    <div class="panel panel-primary">
                        <div class="panel-heading cat-pink"><a href="<?php echo get_category_link(get_cat_ID($cat13)); ?>"><?php echo $cat13;?></a>
                        </div>
                        <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat13,
											'post_type'     => 'post',
											'posts_per_page' => '4'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
										<?php if( $count == 0 ){ ?>
											<div class="panel-body">
												<a href="<?php the_permalink(); ?>">
												<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" >
												</a>
											</div>

											<ul class="list-group">
											<li class="list-group-item"><a href="<?php the_title(); ?>"><?php the_title(); ?></a>
                            </li>			
										<?php }else{ ?>
							<li class="list-group-item"><a href="<?php the_title(); ?>"><?php the_title(); ?></a>
                            </li>			
										
										<?php }  $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
                        </ul>
                        <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat13)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row DAdd hidden-xs">
            <div class="col-xs-12 col-sm-6">
            <?php dynamic_sidebar('adds-middle3-left'); ?>
			</div>
            
            <div class="col-xs-12 col-sm-6">
                <a href="#" target="_blank" rel="nofollow">
                <?php dynamic_sidebar('adds-middle3-right'); ?>
				</a>
            </div>
        </div>
        <div class="row margin-top-10px hidden-xs">
            <div class="col-sm-12">
                <div class="row CarosolHeader">
                    <div class="panel panel-primary">
                        <div class="panel-heading cat-red"><a href="<?php echo get_category_link(get_cat_ID($cat14)); ?>"><?php echo $cat14; ?></a>
                        </div>
                    </div>
                    <div id="LatestCarousel2" class="carousel slide">
                        <a class="right carousel-control" href="#LatestCarousel2" data-slide="next"><i class="fa fa-chevron-right fa-2x"></i></a>
                        <a class="left carousel-control" href="#LatestCarousel2" data-slide="prev"><i class="fa fa-chevron-left fa-2x"></i></a>
                        <div class="carousel-inner">
                            <div class="item active">
								<?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat14,
											'post_type'     => 'post',
											'posts_per_page' => '6'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
									<div class="col-sm-2">
                                    <a href="<?php the_permalink(); ?>">
									<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" >
									</a>
                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                </div>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
                                
                                
                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row margin-top-20px">
            <div class="col-sm-4">
                <div class="row CatLeadBox" style="border-top: 2px solid #006400;">
                    <div class="panel panel-primary visible-xs">
                        <div class="panel-heading cat-green"><a href="<?php echo get_category_link(get_cat_ID($cat15)); ?>"><?php echo $cat15;?></a>
                        </div>
                    </div>
					
					<?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat15,
											'post_type'     => 'post',
											'posts_per_page' => '6'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
									<?php if($count==0){?>
									<a href="<?php the_permalink(); ?>">
									<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive" >
									</a>
									<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
									<?php echo content(30); ?>
								</div>
							</div>
							<div class="col-sm-4 CatBox">
								<div class="panel panel-primary">
									<div class="panel-heading cat-green hidden-xs"><a href="<?php echo get_category_link(get_cat_ID($cat15)); ?>"><?php echo $cat15; ?></a>
									</div>
									<ul class="list-group">
									<?php }else{ ?>
						<li class="list-group-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </li>
									<?php } $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
					
                    </ul>
                    <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat15)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="row DistrictBox">
                    <div class="CatBoxList">
                        <div class="panel panel-primary">
                            <div class="panel-heading"><a href="<?php echo get_category_link(get_cat_ID($cat16)); ?>"><?php echo $cat16; ?></a>
                            </div>
							<?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat16,
											'post_type'     => 'post',
											'posts_per_page' => '3'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
									<div class="media">
										<div class="media-left">
											<a href="<?php the_permalink(); ?>">
											<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="media-object">
											
											</a>
										</div>
										<div class="media-body">
											<h4 class="media-heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
										</div>
									</div>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
                            
                            <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat16)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                            </div>
                        </div>
                    </div>

                    <!--				<div class="hidden-xs">-->
                    <!--				<a href="-->
                    <!--/pages/district-map"><img src="-->
                    <!--/media/common/map-sm.png"></a>-->
                    <!--				</div>-->
                </div>
                <div class="row DistrictArchive">
                    
	
                        <div class="col-sm-12">
                            <label for="cboDivision">আপনার জেলার খবর পড়ুন :</label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <select onchange="myFunction();" name="cboDivision" id="cboDivision" onchange="getDistrict(this.value)" class="form-control">
                                    <option selected="selected" value="0">বিভাগ</option>
                                    <?php 
									$terms = get_terms(array(
										'taxonomy' => 'allcountry',
										'hide_empty' => false,
										'parent'   => 0
									) );
									if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
					
										foreach ( $terms as $term ) {
											?>
											<option value="<?php echo $term->term_id; ?>"><?php echo $term->name; ?></option>											
											<?php
										}

									}
									
									?>
									
                                </select>
							
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="form-group" >
                                <select name="nttl" id="nttl" class="form-control">
									<option selected="selected" value="0">জেলা</option>
								 </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input value="সংবাদ" onclick="test2();" name="submit" id="btnSubmit" class="btn btn-success btn-block" type="button">
                            </div>
                        </div>
          
                </div>
            </div>
        </div>
        <div class="row fullWidthBox">
            <div class="text-center cat-ent-heading visible-xs">
                <h3><a href="<?php echo get_category_link(get_cat_ID($cat17)); ?>"><?php echo $cat17; ?></a></h3>
            </div>
            <div class="text-center hidden-xs" style="margin: 10px 0;">
                <a href=""><img src="<?php echo get_template_directory_uri(); ?>/imgs/binodon-banner.png" class="img-responsive">
                </a>
            </div>

            <div class="row">
                <div class="col-sm-6 LeadBox">
				<?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat17,
											'post_type'     => 'post',
											'posts_per_page' => '9'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
	
									<?php if($count==0) { ?>
										<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive">
										</a>
										<h2><a href=""><?php the_title(); ?></a></h2>
										<?php echo content(30); ?>
									</div>

									<div class="col-sm-6">
										<div class="row SingleBox">
										<?php }elseif( $count==1 || $count==2 || $count==3 ) { ?>
										<div class="col-sm-6">
											<a href=""><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive">
											</a>
											<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
										</div>
										
										<?php }elseif( $count==4 ) { ?>
										<div class="col-sm-6">
											<a href=""><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive">
											</a>
											<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
										</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-12">
											<div class="EntBotomBox">

										<?php }else{?>
										<div class="col-sm-3">
											<div class="media">
												<div class="media-left">
													<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" width="100%">
													</a>
												</div>
												<div class="media-body">
													<h4 class="media-heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
												</div>
											</div>
										</div>
										<?php } $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
				
                    
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row margin-top-10px">
            <div class="row">
                <div class="col-sm-4 CatSingleBox">
                    <div class="panel panel-primary">
                        <div class="panel-heading cat-pink"><a href="<?php echo get_category_link(get_cat_ID($cat18)); ?>"><?php echo $cat18; ?></a>
                        </div>
                        
						<?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat18,
											'post_type'     => 'post',
											'posts_per_page' => '5'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
									<?php if($count==0) { ?>
									<div class="panel-body">
										<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive">
										</a>
									</div>
									<ul class="list-group">
									<?php }else {?>
									<li class="list-group-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
									<?php } $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
						
                        </ul>
                        <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat18)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 CatSingleBox hidden-xs">
                    <div class="panel panel-primary">
                        <div class="panel-heading cat-ash"><a href="<?php echo get_category_link(get_cat_ID($cat19)); ?>"><?php echo $cat19; ?></a>
                        </div>
                        <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat19,
											'post_type'     => 'post',
											'posts_per_page' => '5'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
									<?php if($count==0) { ?>
									<div class="panel-body">
										<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive">
										</a>
									</div>
									<ul class="list-group">
									<?php }else {?>
									<li class="list-group-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
									<?php } $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
                        </ul>
                        <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat19)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 CatSingleBox hidden-xs">
                    <div class="panel panel-primary">
                        <div class="panel-heading cat-blue"><a href="<?php echo get_category_link(get_cat_ID($cat20)); ?>"><?php echo $cat20; ?></a>
                        </div>
                        <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat20,
											'post_type'     => 'post',
											'posts_per_page' => '5'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
									<?php if($count==0) { ?>
									<div class="panel-body">
										<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive">
										</a>
									</div>
									<ul class="list-group">
									<?php }else {?>
									<li class="list-group-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
									<?php } $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
                        </ul>
                        <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat20)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row margin-top-10px">
            <div class="row">
                <div class="col-sm-4 CatSingleBox">
                    <div class="panel panel-primary">
                        <div class="panel-heading cat-pink"><a href="<?php echo get_category_link(get_cat_ID($cat21)); ?>"><?php echo $cat21; ?></a>
                        </div>
                        <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat21,
											'post_type'     => 'post',
											'posts_per_page' => '5'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
									<?php if($count==0) { ?>
									<div class="panel-body">
										<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive">
										</a>
									</div>
									<ul class="list-group">
									<?php }else {?>
									<li class="list-group-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
									<?php } $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
                        </ul>
                        <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat24)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 CatSingleBox">
                    <div class="panel panel-primary">
                        <div class="panel-heading cat-ash"><a href="<?php echo get_category_link(get_cat_ID($cat22)); ?>"><?php echo $cat22; ?></a>
                        </div>
                        <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat22,
											'post_type'     => 'post',
											'posts_per_page' => '5'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
									<?php if($count==0) { ?>
									<div class="panel-body">
										<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive">
										</a>
									</div>
									<ul class="list-group">
									<?php }else {?>
									<li class="list-group-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
									<?php } $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
                        </ul>
                        <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat22)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 CatSingleBox">
                    <div class="panel panel-primary">
                        <div class="panel-heading cat-blue"><a href="<?php echo get_category_link(get_cat_ID($cat23)); ?>"><?php echo $cat23; ?></a>
                        </div>
                        <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat23,
											'post_type'     => 'post',
											'posts_per_page' => '5'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php $count=0; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
									<?php if($count==0) { ?>
									<div class="panel-body">
										<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="img-responsive">
										</a>
									</div>
									<ul class="list-group">
									<?php }else {?>
									<li class="list-group-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
									<?php } $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>
                        </ul>
                        <div class="pull-right"><a href="<?php echo get_category_link(get_cat_ID($cat23)); ?>"><i class="fa fa-arrow-circle-o-right"></i> আরও খবর</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row margin-top-10px">
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading"><a href="<?php echo get_category_link(get_cat_ID($cat24)); ?>" target="_blank"><?php echo $cat24; ?></a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div id="PhotoCarousel" class="carousel slide" data-ride="carousel">
                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                        <?php 
								// the query
								$the_query1 = new WP_Query( array(
											'category_name' => $cat24,
											'post_type'     => 'post',
											'posts_per_page' => '10'

											) ); ?>

								<?php if ( $the_query1->have_posts() ) : ?>

									<!-- pagination here -->

									<!-- the loop -->
									<?php 	$count=0;
											$limit=4; ?>
									<?php while ( $the_query1->have_posts() ) : $the_query1->the_post(); ?>
									
									<?php if( $count < $limit ) { ?>
									<div class="item <?php if($count==0) echo 'active'; ?>">
										<a href="<?php  the_permalink(); ?>"><img src="<?php the_post_thumbnail_url('slider'); ?>" alt="<?php the_title(); ?>">
										</a>
										<div class="carousel-caption hidden-xs"><?php the_title(); ?></div>
									</div>
									
									<?php }elseif( $count==$limit ) {?>
									<div class="item">
										<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url('slider'); ?>" alt="<?php the_title(); ?>">
										</a>
										<div class="carousel-caption hidden-xs"><?php the_title(); ?></div>
									</div>
								</div>

								<!-- Controls -->
								<a class="left carousel-control" href="#PhotoCarousel" role="button" data-slide="prev">
									<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
									<span class="sr-only">Previous</span>
								</a>
								<a class="right carousel-control" href="#PhotoCarousel" role="button" data-slide="next">
									<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
									<span class="sr-only">Next</span>
								</a>
							</div>
						</div>
						<div class="col-sm-4">
							<div id="ElectedNews">
									<?php }else {?>
									<div class="media">
										<div class="media-left">
											<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>">
											</a>
										</div>
										<div class="media-body">
											<h4 class="media-heading"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
										</div>
									</div>
									<?php } $count++; ?>
									<?php endwhile; ?>
									<!-- end of the loop -->

									<!-- pagination here -->

									<?php wp_reset_postdata(); ?>

								<?php else : ?>
									<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
								<?php endif; ?>    
							
							
                    </div>
                </div>
            </div>
        </div>
		
		    <div class="row">
				<?php dynamic_sidebar('adds-footer'); ?>
			</div>
         
        </div>

    </section>
    <?php get_footer(); ?>