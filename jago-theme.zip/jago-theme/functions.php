<?php


include_once('wp_bootstrap_navwalker.php');
include_once('inc/options.php');
include_once('inc/breadcumbs.php');




add_theme_support( 'post-thumbnails', array( 'post', 'page' ) );          // Posts only
 

set_post_thumbnail_size( 480, 250, true );
add_image_size( 'slider', 750, 480, true );

/* Menus */
function jago_register_primary_menu() {
  register_nav_menus(
				array(
      'primary-menu' => __( 'Primary Menu' ),
      'footer-menu' => __( 'Footer Menu' )
    )
  );
}

add_action( 'after_setup_theme', 'jago_register_primary_menu' );

/* sidebar */

add_action( 'widgets_init', 'jago_slug_widgets_init' );
function jago_slug_widgets_init() {
    register_sidebar( array(
        'name' => __( 'Main Sidebar', 'Sidebar' ),
        'id' => 'sidebar',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div class="row" style="margin-bottom:5px;">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	
	/*footer sidebar */
	register_sidebar( array(
        'name' => __( 'Footer Top', 'footer-up' ),
        'id' => 'footer-up',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	/* Footer One */
	register_sidebar( array(
        'name' => __( 'Footer One', 'footer-one' ),
        'id' => 'footer-one',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	/* Footer Two */
	register_sidebar( array(
        'name' => __( 'Footer Two', 'footer-two' ),
        'id' => 'footer-two',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	/* Footer Three */
	register_sidebar( array(
        'name' => __( 'Footer Three', 'footer-three' ),
        'id' => 'footer-three',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	/* Footer Four */
	register_sidebar( array(
        'name' => __( 'Footer Copy Right', 'footer-copy' ),
        'id' => 'footer-copy',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	
	/* ADDS BANNER TOP */
	register_sidebar( array(
        'name' => __( 'ADDS BANNER TOP', 'adds_top' ),
        'id' => 'adds-top',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	/* ADDS MIDLE1 LEFT */
	register_sidebar( array(
        'name' => __( 'ADDS MIDLE1 LEFT', 'adds-middle1-left' ),
        'id' => 'adds-middle1-left',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	/* ADDS MIDLE1 LEFT */
	register_sidebar( array(
        'name' => __( 'ADDS MIDLE1 RIGHT', 'adds-middle1-right' ),
        'id' => 'adds-middle1-right',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	
	/* ADDS MIDLE1 LEFT */
	register_sidebar( array(
        'name' => __( 'ADDS MIDLE2 LEFT', 'adds-middle2-left' ),
        'id' => 'adds-middle2-left',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	/* ADDS MIDLE1 RIGHT */
	register_sidebar( array(
        'name' => __( 'ADDS MIDLE2 RIGHT', 'adds-middle2-right' ),
        'id' => 'adds-middle2-right',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	
	/* ADDS MIDLE3 LEFT */
	register_sidebar( array(
        'name' => __( 'ADDS MIDLE3 LEFT', 'adds-middle3-left' ),
        'id' => 'adds-middle3-left',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	/* ADDS MIDLE1 LEFT */
	register_sidebar( array(
        'name' => __( 'ADDS MIDLE3 RIGHT', 'adds-middle3-right' ),
        'id' => 'adds-middle3-right',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	
	/* ADDS FOOTER */
	register_sidebar( array(
        'name' => __( 'ADDS FOOTER', 'adds-footer' ),
        'id' => 'adds-footer',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'theme-slug' ),
        'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 style="display:none;">',
		'after_title'   => '</h2>',
    ) );
	
}

// Register Custom Taxonomy
function custom_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Countrynews', 'Taxonomy General Name', 'text_domain' ),
		'singular_name'              => _x( 'Countrynews', 'Taxonomy Singular Name', 'text_domain' ),
		'menu_name'                  => __( 'Countrynews', 'text_domain' ),
		'all_items'                  => __( 'All Items', 'text_domain' ),
		'parent_item'                => __( 'Parent Item', 'text_domain' ),
		'parent_item_colon'          => __( 'Parent Item:', 'text_domain' ),
		'new_item_name'              => __( 'New Item Name', 'text_domain' ),
		'add_new_item'               => __( 'Add New Item', 'text_domain' ),
		'edit_item'                  => __( 'Edit Item', 'text_domain' ),
		'update_item'                => __( 'Update Item', 'text_domain' ),
		'view_item'                  => __( 'View Item', 'text_domain' ),
		'separate_items_with_commas' => __( 'Separate items with commas', 'text_domain' ),
		'add_or_remove_items'        => __( 'Add or remove items', 'text_domain' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'text_domain' ),
		'popular_items'              => __( 'Popular Items', 'text_domain' ),
		'search_items'               => __( 'Search Items', 'text_domain' ),
		'not_found'                  => __( 'Not Found', 'text_domain' ),
		'no_terms'                   => __( 'No items', 'text_domain' ),
		'items_list'                 => __( 'Items list', 'text_domain' ),
		'items_list_navigation'      => __( 'Items list navigation', 'text_domain' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'allcountry', array( 'post' ), $args );

}
add_action( 'init', 'custom_taxonomy', 0 );


function wpdocs_theme_name_scripts() {
    wp_enqueue_script( 'sdk', get_template_directory_uri() . '/js/appsdj.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'wpdocs_theme_name_scripts' );


/* test */

function more_post_ajax(){
    $term = $_POST["terms_val"];

    header("Content-Type: text/html");

	$child = get_term_children( $term, 'allcountry' ); 

	if ( ! empty( $child ) ){
						
		foreach ( $child as $s_shild ) {
			$term_child = get_term_by( 'id', $s_shild, 'allcountry' );
			echo '<option value="'.get_term_link( $term_child ).'"> '.$term_child->name.' </option>';										
		}

	}


exit; 
}

add_action('wp_ajax_nopriv_jago_taxo_show', 'more_post_ajax'); 
add_action('wp_ajax_jago_taxo_show', 'more_post_ajax');

/* Popular post */
function jago_set_post_views($postID) {

    $count_key = 'wpb_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }

}

//To keep the count accurate, lets get rid of prefetching

remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);

function jago_track_post_views($post_id) {
    if ( !is_single() ) return;
    if ( empty ( $post_id) ) {
        global $post;
        $post_id = $post->ID;   
    }
    jago_set_post_views($post_id);
}
add_action( 'wp_head', 'jago_track_post_views');


function jago_get_post_views($postID){

    $count_key = 'wpb_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0 View";
    }
    return $count.' Views';
}

/* theme admin panel */
function theme_settings_page(){
    ?>
	    <div class="wrap">
	    <h1>Theme Panel</h1>
	    <form method="post" action="options.php" enctype="multipart/form-data">
	        <?php
	            settings_fields("section");
	            do_settings_sections("theme-options");      
	            submit_button(); 
	        ?>          
	    </form>
		</div>
	<?php



}

function add_theme_menu_item()
{
	add_menu_page("Theme Panel", "Theme Panel", "manage_options", "theme-panel", "theme_settings_page", null, 99);
}

add_action("admin_menu", "add_theme_menu_item");


function content($limit) {
  $content = explode(' ', get_the_content(), $limit);
  if (count($content)>=$limit) {
    array_pop($content);
    $content = implode(" ",$content).'...';
  } else {
    $content = implode(" ",$content);
  }	
  $content = preg_replace('/[.+]/','', $content);
  $content = apply_filters('the_content', $content); 
  $content = str_replace(']]>', ']]&gt;', $content);
  return wp_strip_all_tags($content);
}




?>